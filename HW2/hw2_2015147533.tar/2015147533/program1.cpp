#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

using namespace std;

int fnum=0, frow=0, fcolumn=0; //filter number and row, column
int drow=0, dcolumn=0; //data row, column
int rrow=0, rcolumn=0; //result row, column

int ***data;
int ****filter;
int ****result;
int ***real_result;

void make_filter(int num, int row, int column){

    int read1 =0;
	for(int n=0; n<num;n++){
	    for(int c=0; c<3 ; c++){
	        for(int a=0; a<row ; a++){
	            for(int b=0; b<column ;b++){    
					cin>> read1;
       				filter[n][c][a][b] = read1;
	            }
       		}
	    }
	}
	
}

//read input the data for filter array


void calculate(){
	for(int d=0;d<fnum;d++){
		for(int a=0;a<3;a++){
			for(int b=0;b<rrow;b++){
				for(int c=0;c<rcolumn;c++){
					for(int t=0;t<frow;t++){
						for(int k=0;k<fcolumn;k++){
							if(t==0 && k==0){
								result[d][a][b][c]=(data[a][b+t][c+k]*filter[d][a][t][k]);
							}
							else{
								result[d][a][b][c]=result[d][a][b][c]+(data[a][b+t][c+k]*filter[d][a][t][k]);
							}
						}
					}
				}
				
			}		
		}
	}
}

//calculating filter and data and put the result into result array

int main(){
	
	struct timeval start,end;
	gettimeofday(&start,NULL);
	long miltime;
    cin>> fnum; cin>> frow; cin>> fcolumn;
	
	filter = new int ***[fnum];
	for(int i=0;i<fnum;i++){
		filter[i]=new int**[3];
		for(int j=0;j<3;j++){
			filter[i][j]=new int*[frow];
			for(int k=0;k<frow;k++){
				filter[i][j][k]=new int[fcolumn];
			}
		}
	} 
	//allocate filter array

    int read =0;

	make_filter(fnum,frow,fcolumn); 
	// call the making filter

	cin>>drow; cin>> dcolumn;
	
	
	data = new int **[3];
	for(int j=0;j<3;j++){
		data[j]=new int*[drow+2];
		for(int k=0;k<drow+2;k++){
			data[j][k]=new int[dcolumn+2];
		}
	}
	//allocate data array

	for(int c=0; c<3 ; c++){
		for(int a=0; a<drow+2 ; a++){
	    	for(int b=0; b<dcolumn+2 ;b++){    
				
       			data[c][a][b] = 0;
	        }
       	}
	}
	// makeing 0 filter for each edge
	for(int c=0; c<3 ; c++){
		for(int a=1; a<drow+1 ; a++){
	    	for(int b=1; b<dcolumn+1 ;b++){    
				cin>> read;
       			data[c][a][b] = read;
	        }
       	}
	}
	// reading the data


	rrow = drow -frow +3;
	rcolumn = dcolumn -fcolumn +3;

	result = new int ***[fnum];
	for(int i=0;i<fnum;i++){
		result[i]=new int** [3];
		for(int j=0;j<3;j++){
			result[i][j]=new int* [rrow];
			for(int k=0;k<rrow;k++){
				result[i][j][k]=new int[rcolumn];
			}
		}
	}
	//allocate result array

	calculate();
	//calling the calculate

	real_result= new int **[fnum];
	for(int j=0;j<fnum;j++){
		real_result[j]=new int* [rrow];
		for(int k=0;k<rrow;k++){
			real_result[j][k]=new int[rcolumn];
		}
	}
	//allocate real_result array

	for(int a=0;a<fnum;a++){
		for(int b=0;b<3;b++){
			for(int c=0;c<rrow;c++){
				for(int d=0;d<rcolumn;d++){
					if(b==0){
						real_result[a][c][d]=result[a][b][c][d];
					}
					else{
						real_result[a][c][d]=real_result[a][c][d]+result[a][b][c][d];	
					}
				}			
			}
		}
	}

	//adding 3 size of result to real_result array
	for(int a=0;a<fnum;a++){
		for(int c=0;c<rrow;c++){
			for(int d=0;d<rcolumn;d++){
				if(real_result[a][c][d]<0){
					real_result[a][c][d]=0;
				}
				cout<<real_result[a][c][d]<<" ";
			}
			cout<<endl;			
		}
		cout<<endl;
	}

	// showing the output

	gettimeofday(&end,NULL);
	miltime = (end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;

	cout<<miltime<<endl;
	
	//showing the result
return 0;
}  
