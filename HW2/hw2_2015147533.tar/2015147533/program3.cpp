#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <thread>
#include <vector>
#include <pthread.h>

int fnum=0, frow=0, fcolumn=0; //filter number and row, column
int drow=0, dcolumn=0; //data row, column
int rrow=0, rcolumn=0; //result row, column

struct timeval th_start,th_end;

using namespace std;
using std::thread;
using std::vector;

int ***data;
int ****filter;
int ****result;
int ***real_result;
long *starttimemil;
long *endtimemil;

void make_filter(int num, int row, int column){

    int read1 =0;
	for(int n=0; n<num;n++){
	    for(int c=0; c<3 ; c++){
	        for(int a=0; a<row ; a++){
	            for(int b=0; b<column ;b++){    
					cin>> read1;
       				filter[n][c][a][b] = read1;
	            }
       		}
	    }
	}
}
//read input the data for filter array


void calculate(int start,int end){

	gettimeofday(&th_start,NULL);

	starttimemil[start] = (th_start.tv_sec*1000)+(th_start.tv_usec)/1000; //input the start time of thread

	for(int d=start;d<end;d++){
		for(int a=0;a<3;a++){
			for(int b=0;b<rrow;b++){
				for(int c=0;c<rcolumn;c++){
					for(int t=0;t<frow;t++){
						for(int k=0;k<fcolumn;k++){
							if(t==0 && k==0){
								result[d][a][b][c]=(data[a][b+t][c+k]*filter[d][a][t][k]);
							}
							else{
								result[d][a][b][c]=result[d][a][b][c]+(data[a][b+t][c+k]*filter[d][a][t][k]);
							}
						}
					}
				}
				
			}		
		}
	}
	gettimeofday(&th_end,NULL);
	endtimemil[start]=(th_end.tv_sec*1000)+(th_end.tv_usec)/1000; //input the end time of thread
	
}

//calculating filter and data and put the result into result array

int main(int argc, char** argv){
	
	struct timeval start,end;
	gettimeofday(&start,NULL);
	long miltime;
    cin>> fnum; cin>> frow; cin>> fcolumn;
    
	filter = new int ***[fnum];
	for(int i=0;i<fnum;i++){
		filter[i]=new int**[3];
		for(int j=0;j<3;j++){
			filter[i][j]=new int*[frow];
			for(int k=0;k<frow;k++){
				filter[i][j][k]=new int[fcolumn];
			}
		}
	}
	//allocate the filter array
	
	int read=0;


	make_filter(fnum,frow,fcolumn);
	// call the making filter

	cin>>drow; cin>> dcolumn;
	
	data = new int **[3];
	for(int j=0;j<3;j++){
		data[j]=new int*[drow+2];
		for(int k=0;k<drow+2;k++){
			data[j][k]=new int[dcolumn+2];
		}
	}
	//allocate the data array

	for(int c=0; c<3 ; c++){
		for(int a=0; a<drow+2 ; a++){
	    	for(int b=0; b<dcolumn+2 ;b++){    
				
       			data[c][a][b] = 0;
	        }
       	}
	}

	// makeing 0 filter for each edge

	for(int c=0; c<3 ; c++){
		for(int a=1; a<drow+1 ; a++){
	    	for(int b=1; b<dcolumn+1 ;b++){    
				cin>> read;
       			data[c][a][b] = read;
	        }
       	}
	}
	// reading the data


	rrow = drow -frow +3;
	rcolumn = dcolumn -fcolumn +3;

	result = new int ***[fnum];
	for(int i=0;i<fnum;i++){
		result[i]=new int** [3];
		for(int j=0;j<3;j++){
			result[i][j]=new int* [rrow];
			for(int k=0;k<rrow;k++){
				result[i][j][k]=new int[rcolumn];
			}
		}
	}
	//allocate the result array

	int thread_num =atoi (argv[1]); 

	int each_num = fnum/thread_num;
	int else_num = fnum%thread_num;
	int remain =1;
	int insertstart=0, insertend=0;
	vector<thread> adding;
	
	starttimemil=new long[fnum];
	endtimemil=new long[fnum];
	long *thread_time = new long[thread_num];

	if(each_num==0){
		for(int k=0;k<else_num;k++){	
			adding.push_back(thread(calculate,k,(k+1)));
		}
		for(int t=0;t<else_num;t++){
			adding[t].join();
		}
		for(int p=0;p<else_num;p++){	
			thread_time[p]=endtimemil[p]-starttimemil[p];
		}
	}
	//when fnum is less than thread_num, calculate in thread and calculate the time

	else{
		for(int k=0;k<thread_num;k++){
			if(else_num==0){
				remain = 0;
			}
			if(k==0){
				insertstart=0;
				insertend=each_num+remain;
			}
			else{
				insertstart=insertend;
				insertend=insertstart+each_num+remain;
			}

			adding.push_back(thread(calculate,insertstart,insertend));
			else_num= else_num-1;
		}
		for(int t=0;t<thread_num;t++){

			adding[t].join();

		}
		remain=1;
		else_num = fnum%thread_num;
		for(int p=0;p<thread_num;p++){
			if(else_num==0){
				remain = 0;
			}
			if(p==0){
				insertstart=0;
				insertend=each_num+remain;
			}
			else{
				insertstart=insertend;
				insertend=insertstart+each_num+remain;
			}
			thread_time[p]=endtimemil[insertstart]-starttimemil[insertstart];
			else_num= else_num-1;
		}

	}
	//when fnum is more than thread_num, calculate in thread and calculate the time

	real_result= new int **[fnum];
	for(int j=0;j<fnum;j++){
		real_result[j]=new int* [rrow];
		for(int k=0;k<rrow;k++){
			real_result[j][k]=new int[rcolumn];
		}
	}
	//allocate the real_result

	for(int a=0;a<fnum;a++){
		for(int b=0;b<3;b++){
			for(int c=0;c<rrow;c++){
				for(int d=0;d<rcolumn;d++){
					if(b==0){
						real_result[a][c][d]=result[a][b][c][d];
					}
					else{
						real_result[a][c][d]=real_result[a][c][d]+result[a][b][c][d];	
					}
				}			
			}
		}
	}

	//adding 3 size of result to real_result array

	for(int a=0;a<fnum;a++){
		for(int c=0;c<rrow;c++){
			for(int d=0;d<rcolumn;d++){
				if(real_result[a][c][d]<0){
					real_result[a][c][d]=0;
				}
				cout<<real_result[a][c][d]<<" ";
			}
			cout<<endl;			
		}
		cout<<endl;
	}

	for(int o=0;o<thread_num;o++){
		if(each_num==0 && o==else_num){
			break;
		}
	}

	// showing the output
	
	for(int p=0;p<thread_num;p++){
		if(each_num==0 && p==else_num){
			break;
		}
		cout<<thread_time[p]<<" ";
		
	}
	//showing the thread time

	cout<<endl;

	gettimeofday(&end,NULL);
	miltime = (end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;

	cout<<miltime<<endl;
	//showing the whole time
	
return 0;
}  
