#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <string>
#include <sys/time.h>
#include <cstdio>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

using namespace std;


int fnum=0, frow=0, fcolumn=0; //filter number and row, column
int drow=0, dcolumn=0; //data row, column
int rrow=0, rcolumn=0; //result row, column

int ***data;
int ****filter;

void make_filter(int num, int row, int column){

    int read1 =0;
	for(int n=0; n<num;n++){
	    for(int c=0; c<3 ; c++){
	        for(int a=0; a<row ; a++){
	            for(int b=0; b<column ;b++){    
					cin>> read1;
       				filter[n][c][a][b] = read1;
	            }
       		}
	    }
	}
	
}

//read input the data for filter array



int main(int argc, char** argv){
	
	struct timeval start,end;
	gettimeofday(&start,NULL);
	long miltime;

    cin>> fnum; cin>> frow; cin>> fcolumn;

    
    int read =0;

	filter = new int ***[fnum];
	for(int i=0;i<fnum;i++){
		filter[i]=new int**[3];
		for(int j=0;j<3;j++){
			filter[i][j]=new int*[frow];
			for(int k=0;k<frow;k++){
				filter[i][j][k]=new int[fcolumn];
			}
		}
	}
	//allocate filter array

	make_filter(fnum,frow,fcolumn); 
	// call the making filter

	cin>>drow; cin>> dcolumn;
	
	data = new int **[3];
	for(int j=0;j<3;j++){
		data[j]=new int*[drow];
		for(int k=0;k<drow;k++){
			data[j][k]=new int[dcolumn];
		}
	}
	//allocate data array

	for(int c=0; c<3 ; c++){
		for(int a=0; a<drow ; a++){
	    	for(int b=0; b<dcolumn;b++){    
				cin>> read;
       			data[c][a][b] = read;
	        }
       	}
	}
	// reading the data
	ofstream reading;
	int div = atoi(argv[1]); 	int share = fnum/div; 	int remain = fnum%div; 	int add=1;
	string awri = "newinput"; string bwri; string cwri; string write;
	int insertstart=0,insertend=0;

	if(share==0){
		for(int i=0;i<fnum;i++){
			bwri = to_string(i);
			cwri = awri+bwri;
			reading.open(cwri);
			if(remain ==0){
				add=0;
			}
			reading<<to_string(share+add)<<" "<<to_string(frow)<<" "<<to_string(fcolumn)<<endl;
			for(int k=i;k<(i+1);k++){
				for(int a=0; a<3;a++){
					for(int b=0;b<frow;b++){
						for(int c=0;c<fcolumn;c++){
							write=to_string(filter[k][a][b][c]);						
							reading<<write;
							if(c!=(fcolumn-1)){
								reading<<" ";
							}
						}
						reading<<endl;
					}
				}
			}
			reading<<to_string(drow)<<" "<<to_string(dcolumn)<<endl;
			for(int a=0; a<3;a++){
				for(int b=0;b<drow;b++){
					for(int c=0;c<dcolumn;c++){
						write=to_string(data[a][b][c]);						
						reading<<write;
						if(c!=(dcolumn-1)){
							reading<<" ";
						}
					}
					reading<<endl;
				}
			}
	
			remain = remain -1;
			reading.close();
		}

	}
	// when process num is more than filternum, writing the new input files

	else{
		for(int i=0;i<div;i++){
			bwri = to_string(i);
			cwri = awri+bwri;
			reading.open(cwri);
			if(remain ==0){
				add=0;
			}
			reading<<to_string(share+add)<<" "<<to_string(frow)<<" "<<to_string(fcolumn)<<endl;
			if(i==0){
				insertstart=0;
				insertend=share+add;
			}
			else{
				insertstart=insertend;
				insertend = insertstart +share +add;
			}
			for(int k=insertstart;k<insertend;k++){
				for(int a=0; a<3;a++){
					for(int b=0;b<frow;b++){
						for(int c=0;c<fcolumn;c++){
							write=to_string(filter[k][a][b][c]);						
							reading<<write;
							if(c!=(fcolumn-1)){
								reading<<" ";
							}
						}
						reading<<endl;
					}
				}
			}
			reading<<to_string(drow)<<" "<<to_string(dcolumn)<<endl;
			for(int a=0; a<3;a++){
				for(int b=0;b<drow;b++){
					for(int c=0;c<dcolumn;c++){
						write=to_string(data[a][b][c]);						
						reading<<write;
						if(c!=(dcolumn-1)){
							reading<<" ";
						}
					}
					reading<<endl;
				}
			}
	
			remain = remain -1;
			reading.close();
		}
	
	}
	
	// when process num is less than filternum, writing the new input files

	int in;
	int out; const char *inpu1 , *outpu1;
	string dwri = "newoutput"; string ewri;
	
	pid_t pid[div];
			
	for(int t=0;t<div;t++){	
		pid[t] =fork();
		if(pid[t] ==0){
			char c[]="./program1";
			char* const args[]={c,NULL};

			bwri=to_string(t);
			cwri=awri + bwri;
			ewri=dwri + bwri;
			inpu1 = cwri.c_str();
			outpu1=ewri.c_str();

			in =open(inpu1,O_RDONLY); 
			out = open(outpu1,O_WRONLY | O_TRUNC |O_CREAT,S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
			dup2(in,0);
			dup2(out,1);
			close(in);
			close(out);
			execvp("./program1",args);
		}
		
	}
	
	// Making the process and change to program1, And write the result to new output files
 
	for(int k=0;k<div;k++){
		int state;
		waitpid(pid[k],&state,0);
	}
	
	//Waiting until process is end

	long time[div]; int prtadd=1; int prtremain = fnum%div; int timecount=0; int prtshare=0;
	ifstream wow;
	rrow = drow -frow +3;
	rcolumn =dcolumn-fcolumn+3;

	if(share==0){
		for(int t=0;t<div;t++){	
			if(fnum==t){
				break;
			}
			bwri=to_string(t);
			ewri=dwri + bwri;
			wow.open(ewri);
			string wow1;
			for(int i=0;i<rrow;i++){
				for(int j=0;j<rcolumn;j++){
					wow>>wow1;
					cout<<wow1<<" ";		
				}
				cout<<endl;
			}
			wow>>wow1;
			time[timecount]=stof(wow1);
			cout<<endl;
			timecount=timecount+1;
			wow.close();
		}	
	}

	//Reading the new output files, when process is more than filter num

	else{
		for(int t=0;t<div;t++){	
			if(prtremain==0){
				prtadd=0;
			}
			bwri=to_string(t);
			ewri=dwri + bwri;
			wow.open(ewri);
			string wow1;
			prtshare=(share+prtadd);
			for(int i=0;i<(share+prtadd);i++){
				for(int y=0;y<rrow;y++){
					for(int j=0;j<rcolumn;j++){
						wow>>wow1;
						cout<<wow1<<" ";	
							
					}
					cout<<endl;
				}
				prtshare=prtshare-1;
				if(prtshare != 0){
					cout<<endl;
				}
			}
			wow>>wow1;
			time[timecount]=stof(wow1);
			cout<<endl;
			prtremain=prtremain-1;
			timecount=timecount+1;
			wow.close();
		}
	}
	//Reading the new output files, when process is less than filter num

	for(int j=0;j<div;j++){
		bwri=to_string(j);
		ewri=dwri + bwri;
		cwri=awri + bwri;
		remove(ewri.c_str());
		remove(cwri.c_str());
	}
	//Remove the new input file and output file

	for(int i=0;i<div;i++){
		if(share==0 &&fnum==i){
			break;
		}
		cout<<time[i]<<" ";
	}
	cout<<endl;

	//Showing the process time
	
	gettimeofday(&end,NULL);
	miltime = (end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;

	cout<<miltime<<endl;
	
	//Showing the whole time
return 0;
}  
