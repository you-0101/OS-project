#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <cstdio>
using namespace std;

int time00=0, vtmem=0, phymem=0, frame=0, timekk=0;
int vtsize=64, physize=32;
int * endtime;
int * starttime;
vector <int> noop;
vector <int> locked;
struct PROCESSID
{

	int pid;
	string name;
	vector <string> alldocu;
	int time;
	int linenum;
	
	int readline; 
	int op;
	int arg;
	
	int sleeptime;
	int iowait;

	int end;
	
	int RRrun;

	vector<float> S;
	vector<float> T;
	float cpubust;

};

FILE* out;


void printscheduler(vector<string> runQ, vector<string> sleepL, vector<string> IOw, PROCESSID  ID,int cycle,int run,int schedul){
	
	
	fprintf(out,"[%d Cycle] Scheduled Process: ", cycle);
	if(schedul==1){
		fprintf(out, "%d %s\n", ID.pid, ID.name.c_str());
	}
	else{
		fprintf(out, "None\n");
	}
	fprintf(out,"Running Process: ");
	if(run==1){
		fprintf(out, "Process#%d running code %s line %d(op %d, arg %d)\n", ID.pid, ID.name.c_str(),ID.readline,ID.op,ID.arg);
	}
	else{
		fprintf(out, "None\n");
	}
	fprintf(out, "RunQueue: ");
	if(runQ.empty()){
		fprintf(out, "Empty\n");
	}
	else{
		for (int a=0;a<runQ.size();a=a+2){
			fprintf(out, "%d(%s) ",stoi(runQ[a]),runQ[a+1].c_str());
		}
	
	fprintf(out,"\n");
	}
	
	fprintf(out, "SleepList: ");
	if(sleepL.empty()){
		fprintf(out, "Empty\n");
	}
	else{
		for (int a=0;a<sleepL.size();a=a+2){
			fprintf(out, "%d(%s) ",stoi(sleepL[a]),sleepL[a+1].c_str());
		}
	
	fprintf(out, "\n");
	}

	fprintf(out, "IOWait List: ");
	if(IOw.empty()){
	 	fprintf(out, "Empty\n");
	}
	else{
		for (int a=0;a<IOw.size();a=a+2){
			fprintf(out, "%d(%s) ",stoi(IOw[a]),IOw[a+1].c_str());
		}
	
	fprintf(out, "\n");
	}
	fprintf(out, "\n");
		
}



struct MEMORY{
	int pid;
	string * aid;
	string * valid;
	int empty;
	
};

int timeaid[10000];
MEMORY * memoryif;
FILE * out1;

void printmemory(int op,int pid,int arg, int num,int timekk, vector<int> memid, string physical []){ 
	string fucname;
	if(op==0 || op==1 || op==2){
		if(op==0){
			fucname="ALLOCATION";
		}
		else if(op==1){
			fucname="ACCESS";
		}
		else if(op==2){
			fucname="RELEASE";
		}
		fprintf(out1, "[%d Cycle] Input : Pid [%d] Function [%s] Alloc ID [%d] Page Num[%d]\n",timekk,pid,fucname.c_str(),arg,num);
	}
//op 1,2,3 print
	else if(op==-1){
	
		fprintf(out1, "[%d Cycle] Input : Function [NO-OP]\n",timekk);
	}
//no op print
	else{
		if(op==3){
			fucname="NONMEMORY";
		}
		else if(op==4){
			fucname="SLEEP";
		}
		else if(op==5){
			fucname="IOWAIT";
		}
		else if(op==6){
			fucname="LOCK";
		}
		else if(op==7){
			fucname="UNLOCK";
		}		
		fprintf(out1, "[%d Cycle] Input : Pid [%d] Function [%s]\n",timekk,pid,fucname.c_str());
	}

//print the physical memory

	fprintf(out1, "%-30s", ">> Physical Memory : ");

	for(int a=0;a<physize;a++){
		if(a%4==0){
			fprintf(out1, "|");
		}
		fprintf(out1, "%s",physical[a].c_str());
	}
	fprintf(out1, "|\n");

//print the each aid and valid

	int temp=0;	
	for(int a=0;a<memid.size();a++){
		temp=memid[a];
		fprintf(out1,">> pid(%d) %-20s",temp,"Page Table(AID) : ");

		for(int b=0;b<vtsize;b++){
			if(b%4==0){
				fprintf(out1, "|");
			}
			fprintf(out1,"%s",memoryif[temp].aid[b].c_str());
		}
		fprintf(out1, "|\n");
		fprintf(out1,">> pid(%d) %-20s",temp,"Page Table(Valid) : ");

		for(int b=0;b<vtsize;b++){
			if(b%4==0){
				fprintf(out1, "|");
			}
			fprintf(out1,"%s",memoryif[temp].valid[b].c_str());
		}
		fprintf(out1, "|\n");

	}
	fprintf(out1, "\n");
}

//-----------------------------------------------------------------FIFO----------------------------------------------------------------------
void FIFO(vector<string> order){
	
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}

//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int num=0;
	int aid=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	vector <int> memid;

	for(int p=0;p<10000;p++){
		timeaid[p]=0;
	}
//starting calculation

	while(1){

		timekk++;
		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}

//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data


		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg

		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}
	
		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}

//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}

//check the memory that exit or not		
		if(op==0){
			aid++;

			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					exit=1;
				}
			}
//check exist or not	
			if(exit==0){
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;
						for(int n=0;n<aid+1;n++){
							if(n==0){
								max=timeaid[n];
								min=n;
							}
							else if(max<timeaid[n]){
								max=timeaid[n];
								min=n;
							}
						}
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(min)){
								physical[s]="-";
							}
						}
						timeaid[min]=0;
						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
									
					
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){

						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){

			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;
//print out the result
		for(int p=0;p<aid+1;p++){
			if(timeaid[p]!=0){
				timeaid[p]++;

			}
		}
//increase the stay time
		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}

//-----------------------------------------------------------------LFU----------------------------------------------------------------------


void LFU(vector<string> order){
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}
//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int aid=0;
	int num=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	vector <int> memid;
	for(int p=0;p<10000;p++){
		timeaid[p]=0;
	}
//starting calculation
	while(1){
		timekk++;
		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}
//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data

		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg
		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}

		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}
//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}
//check the memory that exit or not		
		if(op==0){
			aid++;

			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					timeaid[arg]++; //difference with fifo initialize the time
					exit=1;
				}
			}
//check exist or not			
			if(exit==0){
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;
						for(int n=0;n<aid+1;n++){
							if(n==0){
								min=9999;
								if(timeaid[n] !=0){
									min=timeaid[n];
								}
								max=n;
							}
							else if(timeaid[n] !=0 && min>timeaid[n]){
								min=timeaid[n];
								max=n;
							}
						}
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(max)){
								physical[s]="-";
							}
						}
						timeaid[max]=0;

						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									min=9999;
									if(timeaid[n] !=0){
										min=timeaid[n];
									}
									max=n;
								}
								else if(timeaid[n] !=0 && min>timeaid[n]){
									min=timeaid[n];
									max=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							timeaid[max]=0;

							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									min=9999;
									if(timeaid[n] !=0){
										min=timeaid[n];
									}
									max=n;
								}
								else if(timeaid[n] !=0 && min>timeaid[n]){
									min=timeaid[n];
									max=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							timeaid[max]=0;
							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									min=9999;
									if(timeaid[n] !=0){
										min=timeaid[n];
									}
									max=n;
								}
								else if(timeaid[n] !=0 && min>timeaid[n]){
									min=timeaid[n];
									max=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							timeaid[max]=0;
							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									min=9999;
									if(timeaid[n] !=0){
										min=timeaid[n];
									}
									max=n;
								}
								else if(timeaid[n] !=0 && min>timeaid[n]){
									min=timeaid[n];
									max=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							timeaid[max]=0;
							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									min=9999;
									if(timeaid[n] !=0){
										min=timeaid[n];
									}
									max=n;
								}
								else if(timeaid[n] !=0 && min>timeaid[n]){
									min=timeaid[n];
									max=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							timeaid[max]=0;
							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){

			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;


//print out the result

		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}


//-----------------------------------------------------------------MFU----------------------------------------------------------------------


void MFU(vector<string> order){
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}
//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int num=0;
	int aid=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	vector <int> memid;
	for(int p=0;p<10000;p++){
		timeaid[p]=0;
	}
//starting calculation
	while(1){
		timekk++;
		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}
//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data

		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg
		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}

		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}
//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}
//check the memory that exit or not		
		if(op==0){
			aid++;

			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					timeaid[arg]++; //difference with fifo initialize the time
					exit=1;
				}
			}
//check exist or not			
			if(exit==0){
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;
						for(int n=0;n<aid+1;n++){
							if(n==0){
								max=timeaid[n];
								min=n;
							}
							else if(max<timeaid[n]){
								max=timeaid[n];
								min=n;
							}
						}
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(min)){
								physical[s]="-";
							}
						}
						timeaid[min]=0;
						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
									
					
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
							for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){

			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;
//print out the result

		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}

//-----------------------------------------------------------------LRU_SAMPLED----------------------------------------------------------------------

void LRU_SAMPLED(vector<string> order){
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}
//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int num=0;
	int aid=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	vector <int> memid;
	int refer[10000][8];
	for(int b=0;b<10000;b++){
		for(int c=0;c<8;c++){
			refer[b][c]=0;
		}
	}
	int totalnum[10000];

	for(int p=0;p<10000;p++){
		timeaid[p]=0;
		totalnum[p]=0;
	}

//starting calculation
	while(1){
		timekk++;
		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}
//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data

		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg
		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}
		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}
//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}
//check the memory that exit or not		
		if(op==0){
			aid++;;
			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					if(timeaid[arg]==0){
						timeaid[arg]=1;
						totalnum[arg]=totalnum[arg]+256;
					}
					timeaid[arg]=1; //difference with fifo initialize the time
					exit=1;
				}
			}
//check exist or not			
			if(exit==0){
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;
						min=512;
						for(int n=0;n<aid+1;n++){
							for(int v=0;v<physize;v++){
								if(physical[v]==to_string(n)){
									if(min>totalnum[n]){
										min=totalnum[n];
										max=n;
									}										
								}
							}
						}
					
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(max)){
								physical[s]="-";
							}
						}
						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								if(timeaid[arg]==0){
									timeaid[arg]=1;
									totalnum[arg]=totalnum[arg]+256;
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
									
					
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							min=512;
							for(int n=0;n<aid+1;n++){
								for(int v=0;v<physize;v++){
									if(physical[v]==to_string(n)){
										if(min>totalnum[n]){
											min=totalnum[n];
											max=n;
										}										
									}
								}
							}
						
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}

							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									if(timeaid[arg]==0){
										timeaid[arg]=1;
										totalnum[arg]=totalnum[arg]+256;
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							min=512;
							for(int n=0;n<aid+1;n++){
								for(int v=0;v<physize;v++){
									if(physical[v]==to_string(n)){
										if(min>totalnum[n]){

											min=totalnum[n];

											max=n;
										}										
									}
								}
							}
						
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									if(timeaid[arg]==0){
										timeaid[arg]=1;
										totalnum[arg]=totalnum[arg]+256;
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							min=512;
							for(int n=0;n<aid+1;n++){
								for(int v=0;v<physize;v++){
									if(physical[v]==to_string(n)){
										if(min>totalnum[n]){

											min=totalnum[n];

											max=n;
										}										
									}
								}
							}
						
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									if(timeaid[arg]==0){
										timeaid[arg]=1;
										totalnum[arg]=totalnum[arg]+256;
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							min=512;
							for(int n=0;n<aid+1;n++){
								for(int v=0;v<physize;v++){
									if(physical[v]==to_string(n)){
										if(min>totalnum[n]){

											min=totalnum[n];

											max=n;
										}										
									}
								}
							}
						
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									if(timeaid[arg]==0){
										timeaid[arg]=1;
										totalnum[arg]=totalnum[arg]+256;
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
							for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							if(timeaid[arg]==0){
								timeaid[arg]=1;
								totalnum[arg]=totalnum[arg]+256;
							}
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							min=512;
							for(int n=0;n<aid+1;n++){
								for(int v=0;v<physize;v++){
									if(physical[v]==to_string(n)){
										if(min>totalnum[n]){

											min=totalnum[n];

											max=n;
										}										
									}
								}
							}
						
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(max)){
									physical[s]="-";
								}
							}
							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									if(timeaid[arg]==0){
										timeaid[arg]=1;
										totalnum[arg]=totalnum[arg]+256;
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){
			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;



//print out the result
		int score=0;
		if(timekk%8==0){
			for(int y=0;y<aid+1;y++){
				for(int v=6;v>-1;v--){
					refer[y][v+1]=refer[y][v];
				}
				refer[y][0]=timeaid[y];
			}
			for(int x=0;x<aid+1;x++){
				timeaid[x]=0;
			}
			for(int f=0;f<aid+1;f++){
				for(int g=0;g<8;g++){
					if(refer[f][g]==1){
						if(g==0){
							score=score+128;
						}
						else if(g==1){
							score=score+64;
						}
						else if(g==2){
							score=score+32;
						}
						else if(g==3){
							score=score+16;
						}
						else if(g==4){
							score=score+8;
						}
						else if(g==5){
							score=score+4;
						}
						else if(g==6){
							score=score+2;
						}
						else if(g==7){
							score=score+1;
						}
					}
				}
				totalnum[f]=score;
				score=0;
			}
		}
//update the reference byte

		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}

//-----------------------------------------------------------------LRU-------------------------------------------------------------------------

void LRU(vector<string> order){
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}
//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int num=0;
	int aid=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	vector <int> memid;
	for(int p=0;p<10000;p++){
		timeaid[p]=0;
	}
//starting calculation
	while(1){
		timekk++;
		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}
//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data

		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg
		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}
		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}
//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}
//check the memory that exit or not		
		if(op==0){
			aid++;

			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					timeaid[arg]=1; //difference with fifo initialize the time
					exit=1;
				}
			}
//check exist or not			
			if(exit==0){
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;
						for(int n=0;n<aid+1;n++){
							if(n==0){
								max=timeaid[n];
								min=n;
							}
							else if(max<timeaid[n]){
								max=timeaid[n];
								min=n;
							}
						}
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(min)){
								physical[s]="-";
							}
						}
						timeaid[min]=0;
						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
									
					
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
							for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							for(int n=0;n<aid+1;n++){
								if(n==0){
									max=timeaid[n];
									min=n;
								}
								else if(max<timeaid[n]){
									max=timeaid[n];
									min=n;
								}
							}
							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(min)){
									physical[s]="-";
								}
							}
							timeaid[min]=0;

							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){

			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;

//print out the result
		for(int p=0;p<aid+1;p++){
			if(timeaid[p]!=0){
				timeaid[p]++;

			}
		}
//increase the stay time
		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}

//-----------------------------------------------------------------optimal----------------------------------------------------------------------


void OPTIMAL(vector<string> order){
	string physical[physize];
	for(int n=0;n<physize;n++){
		physical[n]="-";
	}
//initial physical memory
	int mmax=0;
	for(int k=0;k<order.size();k=k+3){
		if(mmax<stoi(order[k])){
			mmax=stoi(order[k]);
		}
	}
//find out the max pid
	memoryif = new MEMORY[mmax+1];
	for(int z=0;z<mmax+1;z++){
		memoryif[z].aid=new string [vtsize];
		memoryif[z].valid=new string [vtsize];
		for(int y=0;y<vtsize;y++){
			memoryif[z].aid[y]="-";
			memoryif[z].valid[y]="-";
		}
	}
//initial the memory information aid, valid array
	int pid;
	int endpid;
	int op;
	int arg;
	int num=0;
	int aid=0;
	int pagefault=0;
	int temp=0;
	int mtemp=0;
	int min=0;
	int max=0;
	int booloptimal=0;
	int optmax=0;
	int optindex=0;
	int optimal[10000];
	vector <int> memid;
	for(int p=0;p<10000;p++){
		timeaid[p]=0;
		optimal[p]=0;
	}
//starting calculation
	while(1){
		timekk++;

		endpid=-1;
		for(int u=0;u<mmax+1;u++){
			if(endtime[u] !=0 && endtime[u]<timekk){
				endtime[u]=0;
				endpid=u;
				break;
			}
		}
//find out the end process
		if(endpid != -1){
			for(int x=0;x<vtsize;x++){
				for(int z=0;z<physize;z++){
					if(memoryif[endpid].aid[x]==physical[z]){
						physical[z]="-";
					}
				}
			}
			for(int b=0;b<memid.size();b++){
				if(endpid==memid[b]){
					memid.erase(memid.begin()+b);
				}
			}
		}
//erase the end process data

		pid=stoi(order[0]);
		op=stoi(order[1]);
		arg=stoi(order[2]);
		order.erase(order.begin(),order.begin()+3);
//put the pid op arg


		for(int p=0;p<10000;p++){
			optimal[p]=0;
		}
		for(int c=0;c<noop.size();c++){
			if(timekk==noop[c]){
				op=-1;
				noop.erase(noop.begin()+c);
			}
		}

		memoryif[pid].pid=pid;
		
		for(int v=0;v<mmax+1;v++){
			if(starttime[v] !=0 && starttime[v] ==timekk){
				starttime[v]=0;
				memid.push_back(v);
				break;
			}
		}
//put the process into memory at the start time
		int boolmem=0;
		for(int u=0;u<memid.size();u++){
			if(pid==memid[u]){
				boolmem=1;
			}
		}
		if(boolmem==0){
			memid.push_back(pid);
		}
//check the memory that exit or not		
		if(op==0){
			aid++;

			for(int q=0;q<vtsize;q++){
				if(memoryif[pid].aid[q]=="-"){
					if((q+arg-1)<vtsize && memoryif[pid].aid[q+arg-1]=="-"){
						for(int v=q;v<q+arg;v++){
							memoryif[pid].aid[v]=to_string(aid);
						}
						break;
					}
				}
			}
		}
//when op is 0
		else if(op==1){

			min=-1;
			max=vtsize;
			for(int l=0;l<memid.size();l++){
					temp=memid[l];

					for(int z=0;z<vtsize;z++){
						if(memoryif[temp].aid[z]==to_string(arg)){
							min=z;
							break;
						}
					}
					for(int z=0;z<vtsize;z++){
						if(z>min && min !=-1 && memoryif[temp].aid[z]!=to_string(arg)){
							max=z;
							break;
						}
					}
					break;
			}
			num=max-min;
			int exit=0;
			for(int u=0;u<physize;u++){
				if(physical[u]==to_string(arg)){
					timeaid[arg]=1; //difference with fifo initialize the time
					exit=1;
				}
			}
//check exist or not			
			if(exit==0){
	 			for(int v=0;v<aid+1;v++){
					booloptimal=0;
						for(int z=0;z<physize;z++){
							if(physical[z]==to_string(v)){
								for(int n=0;n<order.size();n=n+3){
									if(order[n+1]=="1"){
										if(order[n+2]==to_string(v)){
											optimal[v]=n+2;
											booloptimal=1;
											break;
										}
									}
								}
							}
						}
					if(booloptimal==0){
					optimal[v]=999999;
					}
				}
				if((max-min)<5){
					for(int h=0;h<physize;h=h+4){
						if(physical[h]=="-"){
							for(int m=h;m<h+4;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					if(timeaid[arg]==0){
						pagefault++;

						optmax=0;
						for(int g=0;g<aid+1;g++){
							for(int z=0;z<physize;z++){
								if(physical[z]==to_string(g)){
									if(optmax<optimal[g]){
										optmax=optimal[g];
										optindex=g;
									}
								}
							}

						}
						for(int s=0;s<physize;s++){
							if(physical[s]==to_string(optindex)){
								physical[s]="-";
							}
						}
						timeaid[optindex]=0;
						optimal[optindex]=0;
						for(int b=0;b<physize;b=b+4){
							if(physical[b]=="-"){
								for(int m=b;m<b+4;m++){						
									physical[m]=to_string(arg);
								}
								timeaid[arg]=1;
								break;
							}
						}
					}
									
					
				}
//small than 4
				else if((max-min)<9){

					for(int h=0;h<physize;h=h+8){
						if(physical[h]=="-" && physical[h+4]=="-"){
							for(int m=h;m<h+8;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;


						if(timeaid[arg]==0){
							
							optmax=0;
							for(int g=0;g<aid+1;g++){
								for(int z=0;z<physize;z++){
									if(physical[z]==to_string(g)){
										if(optmax<optimal[g]){
											optmax=optimal[g];
											optindex=g;
										}
									}
								}

							}

							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(optindex)){
									physical[s]="-";
								}
							}
							timeaid[optindex]=0;
							optimal[optindex]=0;
							for(int b=0;b<physize;b=b+8){
								if(physical[b]=="-" && physical[b+4]=="-"){
									for(int m=b;m<b+8;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 8
				else if((max-min)<17){

					for(int h=0;h<physize;h=h+16){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"){
							for(int m=h;m<h+16;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}

					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							

							optmax=0;
							for(int g=0;g<aid+1;g++){
								for(int z=0;z<physize;z++){
									if(physical[z]==to_string(g)){
										if(optmax<optimal[g]){
											optmax=optimal[g];
											optindex=g;
										}
									}
								}

							}

							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(optindex)){
									physical[s]="-";
								}
							}
							timeaid[optindex]=0;
							optimal[optindex]=0;

							for(int b=0;b<physize;b=b+16){
								if(physical[b]=="-" && physical[b+4]=="-"&& physical[b+8]=="-"&& physical[b+12]=="-"){
									for(int m=b;m<b+16;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 16
				else if((max-min)<33){

					for(int h=0;h<physize;h=h+32){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
							for(int m=h;m<h+32;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							
							optmax=0;
							for(int g=0;g<aid+1;g++){
								for(int z=0;z<physize;z++){
									if(physical[z]==to_string(g)){
										if(optmax<optimal[g]){
											optmax=optimal[g];
											optindex=g;
										}
									}
								}

							}

							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(optindex)){
									physical[s]="-";
								}
							}
							timeaid[optindex]=0;
							optimal[optindex]=0;
							for(int h=0;h<physize;h=h+32){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"){
									for(int m=h;m<h+32;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 32
				else if((max-min)<65){

					for(int h=0;h<physize;h=h+64){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
							for(int m=h;m<h+64;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							
							optmax=0;
							for(int g=0;g<aid+1;g++){
								for(int z=0;z<physize;z++){
									if(physical[z]==to_string(g)){
										if(optmax<optimal[g]){
											optmax=optimal[g];
											optindex=g;
										}
									}
								}

							}

							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(optindex)){
									physical[s]="-";
								}
							}
							timeaid[optindex]=0;
							optimal[optindex]=0;
							for(int h=0;h<physize;h=h+64){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-"){
									for(int m=h;m<h+64;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 64
				else if((max-min)<129){

					for(int h=0;h<physize;h=h+128){
						if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
								physical[m]=to_string(arg);
							}
							pagefault++;
							timeaid[arg]=1;
							break;
						}
					}
					while(1){
						if(timeaid[arg]==1){
							break;
						}
						pagefault++;
						if(timeaid[arg]==0){
							
							optmax=0;
							for(int g=0;g<aid+1;g++){
								for(int z=0;z<physize;z++){
									if(physical[z]==to_string(g)){
										if(optmax<optimal[g]){
											optmax=optimal[g];
											optindex=g;
										}
									}
								}

							}

							for(int s=0;s<physize;s++){
								if(physical[s]==to_string(optindex)){
									physical[s]="-";
								}
							}
							timeaid[optindex]=0;
							optimal[optindex]=0;
							for(int h=0;h<physize;h=h+128){
								if(physical[h]=="-" && physical[h+4]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+44]=="-"&& physical[h+48]=="-"&& physical[h+52]=="-"&& physical[h+56]=="-"&& physical[h+60]=="-" && physical[h+64]=="-" && physical[h+8]=="-" && physical[h+12]=="-"&& physical[h+16]=="-"&& physical[h+20]=="-"&& physical[h+24]=="-"&& physical[h+28]=="-"&& physical[h+32]=="-" && physical[h+36]=="-" && physical[h+40]=="-"&& physical[h+68]=="-"&& physical[h+72]=="-"&& physical[h+76]=="-"&& physical[h+80]=="-"&& physical[h+84]=="-" && physical[h+88]=="-" && physical[h+92]=="-" && physical[h+96]=="-"&& physical[h+100]=="-"&& physical[h+104]=="-"&& physical[h+108]=="-"&& physical[h+112]=="-"&& physical[h+116]=="-" && physical[h+120]=="-" && physical[h+124]=="-"){
									for(int m=h;m<h+128;m++){						
										physical[m]=to_string(arg);
									}
									timeaid[arg]=1;
									break;
								}
							}
						}
					}
				}
//small than 128
			}

		}
//when the op is 1
		else if(op==2){

			for(int i=0;i<physize;i++){
				if(physical[i]==to_string(arg)){
					physical[i]="-";
				}
			}

			for(int n=0;n<memid.size();n++){
				temp=memid[n];
				for(int w=0;w<vtsize;w++){
					if(memoryif[temp].aid[w]==to_string(arg)){
						memoryif[temp].aid[w]="-";
						num++;
					}
				}
			}
		}
//when the op is 2
		int find=0;


		for(int y=0;y<memid.size();y++){
			temp=memid[y];

			for(int r=0;r<vtsize;r++){
				find=0;
				for(int e=0;e<physize;e++){

					if(memoryif[temp].aid[r]=="-"){
						memoryif[temp].valid[r]="-";
						break;
					}	

					else if(memoryif[temp].aid[r]==physical[e]){
						memoryif[temp].valid[r]="1";
						find=1;
						break;
					}
					if(find==0){
						memoryif[temp].valid[r]="0";
					}

				}
						
			}
		}
//update the valid array
		if(op==0){
			printmemory(op,pid,aid,arg,timekk,memid,physical);
		}
		else if(op==1){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else if(op==2){
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		else{
			printmemory(op,pid,arg,num,timekk,memid,physical);
		}
		num=0;
//print out the result

		if(order.empty()){
			break;
		}		
//check the ending

	}
	
	

	fprintf(out1,"page fault = %d",pagefault);
//print out pagefault

}
//================================================================================================================================================================================================
//================================================================================================================================================================================================
//================================================================================================================================================================================================
//================================================================================================================================================================================================
//================================================================================================================================================================================================



//-----------------------------------------------------------------RR----------------------------------------------------------------------
void RR(string dir,string page){

	string nameinput="input";
	string lastlast=dir+nameinput;
	string openscheduler=dir+"scheduler.txt";
	string openmemory=dir+"memory.txt";
	out = fopen(openscheduler.c_str(),"w");
	out1=fopen(openmemory.c_str(),"w");

	string read; 
	int num=0;
	
	ifstream readfile;
	readfile.open(lastlast);


	readfile>>read;
	num=stoi(read);

	readfile>>read;
	vtmem=stoi(read);

	readfile>>read;
	phymem=stoi(read);

	readfile>>read;
	frame=stoi(read);
	//reading frist line

	vtsize=vtmem/frame;
	physize=phymem/frame;
	
	string * process= new string[num];
	getline(readfile,read);
	for(int k=0;k<num;k++){
		getline(readfile,read);
		process[k]=read;
	}

	readfile.close();
	//end reading input file

	string **readprocess= new string * [num];
	for(int i=0;i<num;i++){
		readprocess[i]=new string[3];
	}
	//allocate readprocess	

	char *str_buff= new char[100];
	string str_arr[100];
	int str_cnt=0;	
	int pidnum=0;
	for(int i=0;i<num;i++){
		strcpy(str_buff,process[i].c_str());
		char *tok = strtok(str_buff,"\t");
		while(tok !=nullptr){
			str_arr[str_cnt++]=string(tok);
			tok = strtok(nullptr,"\t");
		}
		if(str_cnt==2){

			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1].substr(0,str_arr[1].length()-1);
			readprocess[i][2]="-1";
			pidnum++;
		}
		else{
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1];
			readprocess[i][2]=str_arr[2];
		}
		str_cnt=0;		
	}
	
	int prostate=0;
	int ppid=-1;
	int iopid=-1;
	PROCESSID * processif = new PROCESSID[pidnum];
	PROCESSID * processio = new PROCESSID[(num-pidnum)];
	endtime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		endtime[z]=0;
	}
	starttime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		starttime[z]=0;
	}

	for(int b=0;b<num;b++){
		
		if(readprocess[b][2] == "-1"){

			ppid++;
			processif[ppid].pid=ppid;			
			string readingprocessing=dir+readprocess[b][1];

			readfile.open(readingprocessing.c_str());
			processif[ppid].name=readprocess[b][1];
			readfile>>read;
			processif[ppid].time=stoi(readprocess[b][0]);
			starttime[ppid]=stoi(readprocess[b][0]);
			processif[ppid].linenum=stoi(read);
			processif[ppid].readline=0;
			processif[ppid].iowait=0;
			processif[ppid].sleeptime=0;
			processif[ppid].end=0;
			processif[ppid].RRrun=0;
			for(int a=0;a<(processif[ppid].linenum)*2;a++){
				readfile>>read;
				processif[ppid].alldocu.push_back(read);
			}
			readfile.close();

		}
		else{
			iopid++;
			processio[iopid].name=readprocess[b][1];
			processio[iopid].time=stoi(readprocess[b][0]);
			processio[iopid].pid=stoi(readprocess[b][2]);	
		}
	}
	//reading the all code file
	int boollock=0;
	int boolrun=0;
	int boolsche=0;
	int intorun=0;
	int boolio=0;
	vector <string> runQ;
	vector <string> sleepL;
	vector <string> IOW;
	vector <string> allorder;
	int runpid;
	string runname;
	int sleeppid;
	string sleepname;
	string codenum;
	string codetime;

	while(1){

		time00++;
		boollock=0;
		for(int k=0;k<pidnum;k++){
			if(time00==processif[k].time){
				runQ.push_back(to_string(processif[k].pid));
				runQ.push_back(processif[k].name);
				intorun=1;
			}
			
		}
//checked the time and put into runQ

		for(int u=0;u<(num-pidnum);u++){
			if(time00==processio[u].time){
				boolio=1;

			}			
			if(IOW.empty()==0 && boolio==1){
				boolio=0;
				for(int y=0;y<IOW.size();y=y+2){
			
					if(processio[u].pid==stoi(IOW[y])){

						runQ.push_back(IOW[y]);
						runQ.push_back(IOW[y+1]);
						IOW.erase(IOW.begin(),IOW.begin()+2);
					}

				}	
			}
		}
//check the time I/O occurs

		if(sleepL.empty()==0){
			for(int v=0;v<sleepL.size();v=v+2){
				sleeppid=stoi(sleepL[v]);
				processif[sleeppid].sleeptime--;
				sleepname=sleepL[v+1];
				if(processif[sleeppid].sleeptime==0){
					
					sleepL.erase(sleepL.begin()+v,sleepL.begin()+(v+2));
					runQ.push_back(to_string(sleeppid));
					runQ.push_back(sleepname);
				}

			}
		}
//check the sleep time and put into runQ

		if(intorun==1 && boolrun==0){

			boolrun=1;
			boolsche=1;
			runpid=stoi(runQ[0]);
			runname=runQ[1];
			runQ.erase(runQ.begin(),runQ.begin()+2);
			
			processif[runpid].RRrun++;
			processif[runpid].readline++;
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			

			if(processif[runpid].RRrun==10){			//difference with FCFS
				runQ.push_back(to_string(processif[runpid].pid));
				runQ.push_back(processif[runpid].name);
			}
			if(codenum=="4"){
				processif[runpid].RRrun=0;
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
			}
			else if(codenum=="5"){
				processif[runpid].RRrun=0;
				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
			}
			else if(codenum=="6"){
				for(int m=0;m<locked.size();m++){
					if(stoi(codetime)==locked[m]){
						boollock=1;
						break;
					}
				}
				if(boollock==0){
					locked.push_back(stoi(codetime));
				}
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			else if(codenum=="7"){
				for(int m=0;m<locked.size();m++){
					if(stoi(codetime)==locked[m]){
						locked.erase(locked.begin()+m);
						break;
					}
				}
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			if(boollock==1){
				processif[runpid].readline--;
			}
			else{
				processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			}
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				processif[runpid].RRrun=0;
				boolrun=0;
			}
			if(processif[runpid].end=0 && processif[runpid].RRrun==10){
				processif[runpid].RRrun=0;
				runQ.push_back(to_string(processif[runpid].pid));
				runQ.push_back(processif[runpid].name);
				boolrun=0;
			}
			else if(processif[runpid].RRrun==10){ //difference with FCFS
				processif[runpid].RRrun=0;
				boolrun=0;
				boolsche=1;
			}
			intorun=0;

		}

		else if(intorun==0 && boolrun==0){

			if(runQ.empty()){
				boolsche=0;
				noop.push_back(time00);
				printscheduler(runQ,sleepL,IOW,processif[0],time00,boolrun,boolsche);
			}
			else{
				boolrun=1;
				boolsche=1;
				runpid=stoi(runQ[0]);
				runname=runQ[1];
				runQ.erase(runQ.begin(),runQ.begin()+2);
				
				codenum=processif[runpid].alldocu[0];
				codetime=processif[runpid].alldocu[1];
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				processif[runpid].readline++;
				processif[runpid].RRrun++;
				if(processif[runpid].RRrun==10){	//difference with FCFS
					runQ.push_back(to_string(processif[runpid].pid));
					runQ.push_back(processif[runpid].name);
				}
				if(codenum=="4"){
					processif[runpid].RRrun=0;
					sleepL.push_back(to_string(processif[runpid].pid));
					sleepL.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].sleeptime=stoi(codetime);
					boolrun=0;
				}
				else if(codenum=="5"){
					processif[runpid].RRrun=0;
					IOW.push_back(to_string(processif[runpid].pid));
					IOW.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].iowait=1;
					boolrun=0;	
				}
				else if(codenum=="6"){
					for(int m=0;m<locked.size();m++){
						if(stoi(codetime)==locked[m]){
							boollock=1;
							break;
						}
					}
					if(boollock==0){
						locked.push_back(stoi(codetime));
					}
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;

				}
				else if(codenum=="7"){
					for(int m=0;m<locked.size();m++){
						if(stoi(codetime)==locked[m]){
							locked.erase(locked.begin()+m);
							break;
						}
					}
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;

				}
				else{
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;
				}
				if(boollock==1){
					processif[runpid].readline--;
				}
				else{
					processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
				}
				if(processif[runpid].readline==processif[runpid].linenum){
					processif[runpid].end=1;
					endtime[runpid]=time00;
					processif[runpid].RRrun=0;
					boolrun=0;
				}
				else if(processif[runpid].RRrun==10){	//difference with FCFS
					processif[runpid].RRrun=0;
					boolrun=0;
					boolsche=1;
				}
				
			}
		}
		else if(boolrun==1){
			boolsche=0;

			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].readline++;
			processif[runpid].RRrun++;

			if(codenum=="4"){
				processif[runpid].RRrun=0;
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
				boolsche=1;
			}
			else if(codenum=="5"){
				processif[runpid].RRrun=0;
				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
				boolsche=1;
			}
			else if(codenum=="6"){
				for(int m=0;m<locked.size();m++){
					if(stoi(codetime)==locked[m]){
						boollock=1;
						break;
					}
				}
				if(boollock==0){
					locked.push_back(stoi(codetime));
				}
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);

			}
			else if(codenum=="7"){
				for(int m=0;m<locked.size();m++){
					if(stoi(codetime)==locked[m]){
						locked.erase(locked.begin()+m);
						break;
					}
				}
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);

			}
			if(boollock==1){
				processif[runpid].readline--;
			}
			else{
				processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			}
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				processif[runpid].RRrun=0;
				boolrun=0;
			}
			else if(processif[runpid].RRrun==10){		//difference with FCFS
				runQ.push_back(to_string(processif[runpid].pid));
				runQ.push_back(processif[runpid].name);
				processif[runpid].RRrun=0;
				boolrun=0;
				boolsche=1;
			}


			if(intorun==1){
				intorun=0;
			}
		}

		allorder.push_back(to_string(runpid));
		allorder.push_back(codenum);
		allorder.push_back(codetime);

		int end=0;
		for(int o=0;o<pidnum;o++){
			if(processif[o].end !=1){
				end=0;
				break;
			}
			end=1;	
		}
		if(end==1){
			break;
		}
	}

	if(page=="fifo"){
		FIFO(allorder);
	}
	else if(page=="lru"){
		LRU(allorder);
	}
	else if(page=="lru-sampled"){
		LRU_SAMPLED(allorder);
	}
	else if(page=="lfu"){
		LFU(allorder);
	}
	else if(page=="mfu"){
		MFU(allorder);
	}
	else if(page=="optimal"){
		OPTIMAL(allorder);
	}
			
}

//-----------------------------------------------------------------SJF_SIMPLE----------------------------------------------------------------------
void SJF_SIMPLE(string dir,string page){
	string nameinput="input";
	string lastlast=dir+nameinput;
	string openscheduler=dir+"scheduler.txt";
	string openmemory=dir+"memory.txt";
	out = fopen(openscheduler.c_str(),"w");
	out1=fopen(openmemory.c_str(),"w");

	string read; 
	int num=0;
	
	ifstream readfile;
	readfile.open(lastlast);


	readfile>>read;
	num=stoi(read);

	readfile>>read;
	vtmem=stoi(read);

	readfile>>read;
	phymem=stoi(read);

	readfile>>read;
	frame=stoi(read);
	//reading frist line

	vtsize=vtmem/frame;
	physize=phymem/frame;
	string * process= new string[num];
	getline(readfile,read);
	for(int k=0;k<num;k++){
		getline(readfile,read);
		process[k]=read;
	}

	readfile.close();
	//end reading input file

	string **readprocess= new string * [num];
	for(int i=0;i<num;i++){
		readprocess[i]=new string[3];
	}
	//allocate readprocess	


	char *str_buff= new char[100];
	string str_arr[100];
	int str_cnt=0;	
	int pidnum=0;
	for(int i=0;i<num;i++){
		strcpy(str_buff,process[i].c_str());
		char *tok = strtok(str_buff,"\t");
		while(tok !=nullptr){
			str_arr[str_cnt++]=string(tok);
			tok = strtok(nullptr,"\t");
		}
		if(str_cnt==2){
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1].substr(0,str_arr[1].length()-1);
			readprocess[i][2]="-1";
			pidnum++;
		}
		else{
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1];
			readprocess[i][2]=str_arr[2];
		}
		str_cnt=0;		
	}
	//check either i/o or process

	int prostate=0;
	int ppid=-1;
	int iopid=-1;
	PROCESSID * processif = new PROCESSID[pidnum];
	PROCESSID * processio = new PROCESSID[(num-pidnum)];
	endtime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		endtime[z]=0;
	}
	starttime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		starttime[z]=0;
	}
//allocate the data

	for(int b=0;b<num;b++){
		
		if(readprocess[b][2] == "-1"){

			ppid++;
			processif[ppid].pid=ppid;
			string readingprocessing=dir+readprocess[b][1];

			readfile.open(readingprocessing.c_str());
			processif[ppid].name=readprocess[b][1];

			readfile>>read;

			processif[ppid].time=stoi(readprocess[b][0]);
			starttime[ppid]=stoi(readprocess[b][0]);
			processif[ppid].linenum=stoi(read);
			processif[ppid].readline=0;
			processif[ppid].iowait=0;
			processif[ppid].sleeptime=0;
			processif[ppid].end=0;
			processif[ppid].cpubust=0;
			float O=5;
			processif[ppid].S.push_back(O);
			for(int a=0;a<(processif[ppid].linenum)*2;a++){
				readfile>>read;

				processif[ppid].alldocu.push_back(read);

			}
			readfile.close();

		}
		else{
			iopid++;
			processio[iopid].name=readprocess[b][1];
			processio[iopid].time=stoi(readprocess[b][0]);
			processio[iopid].pid=stoi(readprocess[b][2]);	
		}
	}
	//reading the all code file
	int boolrun=0;
	int boolsche=0;
	int intorun=0;
	int boolio=0;
	vector <string> runQ;
	vector <string> sleepL;
	vector <string> IOW;
	vector <string> allorder;

	int runpid;
	string runname;
	int sleeppid;
	string sleepname;
	string codenum;
	string codetime;
	int runout=0;

	//-------------------------------------starting-----------------------------
	while(1){
		time00++;

		for(int k=0;k<pidnum;k++){
			if(time00==processif[k].time){
				runQ.push_back(to_string(processif[k].pid));
				runQ.push_back(processif[k].name);
				intorun=1;
			}
			
		}
		//check the arrive process time

		for(int u=0;u<(num-pidnum);u++){
			if(time00==processio[u].time){
				boolio=1;

			}			
			if(IOW.empty()==0 && boolio==1){
				boolio=0;
				for(int y=0;y<IOW.size();y=y+2){
			
					if(processio[u].pid==stoi(IOW[y])){

						runQ.push_back(IOW[y]);
						runQ.push_back(IOW[y+1]);
						IOW.erase(IOW.begin(),IOW.begin()+2);
					}

				}	
			}
		}
		//check the I/O time and when the I/O come put into runQ

		if(sleepL.empty()==0){
			for(int v=0;v<sleepL.size();v=v+2){
				sleeppid=stoi(sleepL[v]);
				processif[sleeppid].sleeptime--;
				sleepname=sleepL[v+1];
				if(processif[sleeppid].sleeptime==0){
					sleepL.erase(sleepL.begin()+v,sleepL.begin()+(v+2));
					runQ.push_back(to_string(sleeppid));
					runQ.push_back(sleepname);
				}

			}
		}
		//check and reduce the sleep time
		float min=9999;
		int minid=0;
		int mindex=0;
		float SSS=0;
		int temppid=0;
		string tempname;
		if(intorun==1 && boolrun==0){ //not running but there are new arrive process
			boolrun=1;
			boolsche=1;

			for(int b=0;b<runQ.size();b=b+2){
				if(b==0){
					temppid=stoi(runQ[b]);
					minid=temppid;
					min=processif[minid].S.back();
					mindex=0;
				}
				else{
					temppid=stoi(runQ[b]);
					if(min>processif[temppid].S.back()){
						min=processif[runpid].S.back();
						minid=temppid;
						mindex=b;
					}
				}

			}
			
			
//find out the smaller S

			runpid=stoi(runQ[mindex]);
			runname=runQ[mindex+1];
			runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
			processif[runpid].cpubust++;
//selecting here-----------------------------------------------------------------------------------

			
			processif[runpid].readline++;
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
			}
			else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				
				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			intorun=0;
		}

		else if(intorun==0 && boolrun==0){ //not running and no arrive process

			if(runQ.empty()){
				boolsche=0;
				noop.push_back(time00);
				printscheduler(runQ,sleepL,IOW,processif[0],time00,boolrun,boolsche);
			}
			else{
				boolrun=1;
				boolsche=1;

				for(int b=0;b<runQ.size();b=b+2){

					if(b==0){
						temppid=stoi(runQ[b]);
						minid=temppid;
						min=processif[minid].S.back();
						mindex=0;
					}
					else{
						temppid=stoi(runQ[b]);
						if(min>processif[temppid].S.back()){
							min=processif[temppid].S.back();
							minid=runpid;
							mindex=b;
						}
					}
				}
		
			
	//find out the smaller S

				runpid=stoi(runQ[mindex]);
				runname=runQ[mindex+1];
				runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
				processif[runpid].cpubust++;
//select in runq ------------------------------------------------------------------------------------------------------

				processif[runpid].readline++;
				codenum=processif[runpid].alldocu[0];
				codetime=processif[runpid].alldocu[1];
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
					sleepL.push_back(to_string(processif[runpid].pid));
					sleepL.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].sleeptime=stoi(codetime);
					boolrun=0;
				}
				else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
					
					IOW.push_back(to_string(processif[runpid].pid));
					IOW.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].iowait=1;
					boolrun=0;	
				}
				else{
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;
				}
				if(processif[runpid].readline==processif[runpid].linenum){
					processif[runpid].end=1;
					endtime[runpid]=time00;
					boolrun=0;
				}
				
			}
		}
		else if(boolrun==1){ //running now

			boolsche=0;
			for(int b=0;b<runQ.size();b=b+2){

				if(b==0){
					temppid=stoi(runQ[b]);
					minid=temppid;
					min=processif[temppid].S.back();
					mindex=0;
				}
				else{
					temppid=stoi(runQ[b]);
					if(min>processif[temppid].S.back()){
						min=processif[temppid].S.back();
						minid=temppid;
						mindex=b;
					}
				}
			}
			processif[runpid].cpubust++;
			if((processif[runpid].S.back()-processif[runpid].cpubust)>min){ 			//change the running 

				processif[runpid].cpubust--;				
				temppid=stoi(runQ[mindex]);
				tempname=runQ[mindex+1];
				runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
				runQ.push_back(to_string(runpid));
				runQ.push_back(runname);

				runpid=temppid;
				runname=tempname;
				boolsche=1;
				processif[runpid].cpubust++;
			}
	//find out the smaller S

			
			
			processif[runpid].readline++;
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);

			if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
				boolsche=1;
			}
			else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					SSS=(processif[runpid].cpubust/processif[runpid].T.size())+((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1);
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------

				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
				boolsche=1;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);

			}
			boolsche=0;
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}

			if(intorun==1){
				intorun=0;
			}
		}

		allorder.push_back(to_string(runpid));
		allorder.push_back(codenum);
		allorder.push_back(codetime);
		//putting for memory


		int end=0;
		for(int o=0;o<pidnum;o++){
			if(processif[o].end !=1){
				end=0;
				break;
			}
			end=1;	
		}
		if(end==1){
			break;
		}
	}
	//----------------------------------ending-------------------------------------

//--------------------memory start----------------------------------------	
	if(page=="fifo"){
		FIFO(allorder);
	}
	else if(page=="lru"){
		LRU(allorder);
	}
	else if(page=="lru-sampled"){
		LRU_SAMPLED(allorder);
	}
	else if(page=="lfu"){
		LFU(allorder);
	}
	else if(page=="mfu"){
		MFU(allorder);
	}
	else if(page=="optimal"){
		OPTIMAL(allorder);
	}
//---------------------------end all---------------------------------------			
}








//-----------------------------------------------------------------FCFS----------------------------------------------------------------------
void FCFS(string dir, string page){
	string nameinput="input";
	string lastlast=dir+nameinput;
	string openscheduler=dir+"scheduler.txt";
	string openmemory=dir+"memory.txt";
	out = fopen(openscheduler.c_str(),"w");
	out1=fopen(openmemory.c_str(),"w");

	string read; 
	int num=0;

	ifstream readfile;
	readfile.open(lastlast);


	readfile>>read;

	num=stoi(read);

	readfile>>read;
	vtmem=stoi(read);

	readfile>>read;
	phymem=stoi(read);

	readfile>>read;
	frame=stoi(read);
	//reading frist line

	vtsize=vtmem/frame;
	physize=phymem/frame;
	string * process= new string[num];
	getline(readfile,read);
	for(int k=0;k<num;k++){
		getline(readfile,read);
		process[k]=read;
	}

	readfile.close();
	//end reading input file

	string **readprocess= new string * [num];
	for(int i=0;i<num;i++){
		readprocess[i]=new string[3];
	}
	//allocate readprocess	

	char *str_buff= new char[100];
	string str_arr[100];
	int str_cnt=0;	
	int pidnum=0;
	for(int i=0;i<num;i++){
		strcpy(str_buff,process[i].c_str());
		char *tok = strtok(str_buff," \t");
		while(tok !=nullptr){
			str_arr[str_cnt++]=string(tok);
			tok = strtok(nullptr," \t");
		}
		if(str_cnt==2){
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1].substr(0,str_arr[1].length()-1);
			readprocess[i][2]="-1";
			pidnum++;
		}
		else{
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1];
			readprocess[i][2]=str_arr[2];
		}
		str_cnt=0;		
	}
	//check either i/o or process

	int prostate=0;
	int ppid=-1;
	int iopid=-1;
	PROCESSID * processif = new PROCESSID[pidnum];
	PROCESSID * processio = new PROCESSID[(num-pidnum)];
	endtime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		endtime[z]=0;
	}
	starttime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		starttime[z]=0;
	}
//allocate the data
	for(int b=0;b<num;b++){
		
		if(readprocess[b][2] == "-1"){

			ppid++;
			processif[ppid].pid=ppid;

			string readingprocessing=dir+readprocess[b][1];

			readfile.open(readingprocessing.c_str());
			processif[ppid].name=readprocess[b][1];
			readfile>>read;
			processif[ppid].time=stoi(readprocess[b][0]);
			starttime[ppid]=stoi(readprocess[b][0]);
			processif[ppid].linenum=stoi(read);
			processif[ppid].readline=0;
			processif[ppid].iowait=0;
			processif[ppid].sleeptime=0;
			processif[ppid].end=0;
			for(int a=0;a<(processif[ppid].linenum)*2;a++){
				readfile>>read;
				processif[ppid].alldocu.push_back(read);

			}
			readfile.close();

		} //when is the process
		else{
			iopid++;
			processio[iopid].name=readprocess[b][1];
			processio[iopid].time=stoi(readprocess[b][0]);
			processio[iopid].pid=stoi(readprocess[b][2]);	
		} //when is the IO input
	}
	//reading the all code file
	int boolrun=0;
	int boolsche=0;
	int intorun=0;
	int boolio=0;
	vector <string> runQ;
	vector <string> sleepL;
	vector <string> IOW;
	vector <string> allorder;

	int runpid;
	string runname;
	int sleeppid;
	string sleepname;
	string codenum;
	string codetime;
	int runout=0;
	//-------------------------------------starting-----------------------------
	while(1){
		time00++;
		for(int k=0;k<pidnum;k++){
			if(time00==processif[k].time){
				runQ.push_back(to_string(processif[k].pid));
				runQ.push_back(processif[k].name);
				intorun=1;
			}
			
		}
		//check the arrive process time

		for(int u=0;u<(num-pidnum);u++){
			if(time00==processio[u].time){
				boolio=1;

			}			
			if(IOW.empty()==0 && boolio==1){
				boolio=0;
				for(int y=0;y<IOW.size();y=y+2){
			
					if(processio[u].pid==stoi(IOW[y])){

						runQ.push_back(IOW[y]);
						runQ.push_back(IOW[y+1]);
						IOW.erase(IOW.begin(),IOW.begin()+2);
					}

				}	
			}
		}
		//check the I/O time and when the I/O come put into runQ

		if(sleepL.empty()==0){
			for(int v=0;v<sleepL.size();v=v+2){
				sleeppid=stoi(sleepL[v]);
				processif[sleeppid].sleeptime--;
				sleepname=sleepL[v+1];
				if(processif[sleeppid].sleeptime==0){
					
					sleepL.erase(sleepL.begin()+v,sleepL.begin()+(v+2));
					runQ.push_back(to_string(sleeppid));
					runQ.push_back(sleepname);
				}

			}
		}
		//check and reduce the sleep time

		if(intorun==1 && boolrun==0){ //not running but there are new arrive process

			boolrun=1;
			boolsche=1;
			runpid=stoi(runQ[0]);
			runname=runQ[1];
			runQ.erase(runQ.begin(),runQ.begin()+2);
			processif[runpid].readline++;
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			if(codenum=="4"){
				
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
			}
			else if(codenum=="5"){
				
				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			intorun=0;
		}

		else if(intorun==0 && boolrun==0){ //not running and no arrive process

			if(runQ.empty()){
				boolsche=0;
				noop.push_back(time00);
				printscheduler(runQ,sleepL,IOW,processif[0],time00,boolrun,boolsche);
			}
			else{

				boolrun=1;
				boolsche=1;
				runpid=stoi(runQ[0]);
				runname=runQ[1];
				runQ.erase(runQ.begin(),runQ.begin()+2);
				processif[runpid].readline++;
				codenum=processif[runpid].alldocu[0];
				codetime=processif[runpid].alldocu[1];
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				if(codenum=="4"){
					
					sleepL.push_back(to_string(processif[runpid].pid));
					sleepL.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].sleeptime=stoi(codetime);
					boolrun=0;
				}
				else if(codenum=="5"){
					
					IOW.push_back(to_string(processif[runpid].pid));
					IOW.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].iowait=1;
					boolrun=0;	
				}
				else{
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;
				}
				if(processif[runpid].readline==processif[runpid].linenum){
					processif[runpid].end=1;
					endtime[runpid]=time00;
					boolrun=0;
				}
				
			}
		}
		else if(boolrun==1){ //running now

			boolsche=0;
			processif[runpid].readline++;
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
//update process information
			if(codenum=="4"){
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
				boolsche=1;
			}
			else if(codenum=="5"){

				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
				boolsche=1;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);

			}
//print case with op
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}
//when it is end
			if(intorun==1){
				intorun=0;
			}
		}

		allorder.push_back(to_string(runpid));
		allorder.push_back(codenum);
		allorder.push_back(codetime);
		//putting for memory
	
		int end=0;
		for(int o=0;o<pidnum;o++){
			if(processif[o].end !=1){
				end=0;
				break;
			}
			end=1;	
		}
		if(end==1){
			break;
		}
	}
	//----------------------------------ending-------------------------------------

//--------------------memory start----------------------------------------	
	if(page=="fifo"){
		FIFO(allorder);
	}
	else if(page=="lru"){
		LRU(allorder);
	}
	else if(page=="lru-sampled"){
		LRU_SAMPLED(allorder);
	}
	else if(page=="lfu"){
		LFU(allorder);
	}
	else if(page=="mfu"){
		MFU(allorder);
	}
	else if(page=="optimal"){
		OPTIMAL(allorder);
	}
//---------------------------end all---------------------------------------			
}


//-----------------------------------------------------------------SJF_EXP----------------------------------------------------------------------
void SJF_EXP(string dir, string page){

	string nameinput="input";
	string lastlast=dir+nameinput;
	string openscheduler=dir+"scheduler.txt";
	string openmemory=dir+"memory.txt";
	out = fopen(openscheduler.c_str(),"w");
	out1=fopen(openmemory.c_str(),"w");

	string read; 
	int num=0;
	
	ifstream readfile;
	readfile.open(lastlast);


	readfile>>read;
	num=stoi(read);

	readfile>>read;
	vtmem=stoi(read);

	readfile>>read;
	phymem=stoi(read);

	readfile>>read;
	frame=stoi(read);
	//reading frist line

	vtsize=vtmem/frame;
	physize=phymem/frame;
	string * process= new string[num];
	getline(readfile,read);
	for(int k=0;k<num;k++){
		getline(readfile,read);
		process[k]=read;
	}

	readfile.close();
	//end reading input file

	string **readprocess= new string * [num];
	for(int i=0;i<num;i++){
		readprocess[i]=new string[3];
	}
	//allocate readprocess	


	char *str_buff= new char[100];
	string str_arr[100];
	int str_cnt=0;	
	int pidnum=0;
	for(int i=0;i<num;i++){
		strcpy(str_buff,process[i].c_str());
		char *tok = strtok(str_buff,"\t");
		while(tok !=nullptr){
			str_arr[str_cnt++]=string(tok);
			tok = strtok(nullptr,"\t");
		}
		if(str_cnt==2){
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1].substr(0,str_arr[1].length()-1);
			readprocess[i][2]="-1";
			pidnum++;
		}
		else{
			readprocess[i][0]=str_arr[0];
			readprocess[i][1]=str_arr[1];
			readprocess[i][2]=str_arr[2];
		}
		str_cnt=0;		
	}
	//check either i/o or process

	int prostate=0;
	int ppid=-1;
	int iopid=-1;
	PROCESSID * processif = new PROCESSID[pidnum];
	PROCESSID * processio = new PROCESSID[(num-pidnum)];
	endtime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		endtime[z]=0;
	}
	starttime = new int[pidnum];
	for(int z=0;z<pidnum;z++){
		starttime[z]=0;
	}
//allocate the data

	for(int b=0;b<num;b++){
		
		if(readprocess[b][2] == "-1"){

			ppid++;
			processif[ppid].pid=ppid;
			string readingprocessing=dir+readprocess[b][1];

			readfile.open(readingprocessing.c_str());
			processif[ppid].name=readprocess[b][1];

			readfile>>read;

			processif[ppid].time=stoi(readprocess[b][0]);
			starttime[ppid]=stoi(readprocess[b][0]);
			processif[ppid].linenum=stoi(read);
			processif[ppid].readline=0;
			processif[ppid].iowait=0;
			processif[ppid].sleeptime=0;
			processif[ppid].end=0;
			processif[ppid].cpubust=0;
			float O=5;
			processif[ppid].S.push_back(O);
			for(int a=0;a<(processif[ppid].linenum)*2;a++){
				readfile>>read;

				processif[ppid].alldocu.push_back(read);

			}
			readfile.close();

		}
		else{
			iopid++;
			processio[iopid].name=readprocess[b][1];
			processio[iopid].time=stoi(readprocess[b][0]);
			processio[iopid].pid=stoi(readprocess[b][2]);	
		}
	}
	//reading the all code file

	int boolrun=0;
	int boolsche=0;
	int intorun=0;
	int boolio=0;
	vector <string> runQ;
	vector <string> sleepL;
	vector <string> IOW;
	vector <string> allorder;

	int runpid;
	string runname;
	int sleeppid;
	string sleepname;
	string codenum;
	string codetime;
	int runout=0;

	//-------------------------------------starting-----------------------------
	while(1){
		time00++;


		for(int k=0;k<pidnum;k++){
			if(time00==processif[k].time){
				runQ.push_back(to_string(processif[k].pid));
				runQ.push_back(processif[k].name);
				intorun=1;
			}
			
		}
		//check the arrive process time

		for(int u=0;u<(num-pidnum);u++){
			if(time00==processio[u].time){
				boolio=1;

			}			
			if(IOW.empty()==0 && boolio==1){
				boolio=0;
				for(int y=0;y<IOW.size();y=y+2){
			
					if(processio[u].pid==stoi(IOW[y])){

						runQ.push_back(IOW[y]);
						runQ.push_back(IOW[y+1]);
						IOW.erase(IOW.begin(),IOW.begin()+2);
					}

				}	
			}
		}
		//check the I/O time and when the I/O come put into runQ

		if(sleepL.empty()==0){
			for(int v=0;v<sleepL.size();v=v+2){
				sleeppid=stoi(sleepL[v]);
				processif[sleeppid].sleeptime--;
				sleepname=sleepL[v+1];
				if(processif[sleeppid].sleeptime==0){
					sleepL.erase(sleepL.begin()+v,sleepL.begin()+(v+2));
					runQ.push_back(to_string(sleeppid));
					runQ.push_back(sleepname);
				}

			}
		}
		//check and reduce the sleep time
		float min=9999;
		int minid=0;
		int mindex=0;
		float SSS=0;
		int temppid=0;
		string tempname;
		if(intorun==1 && boolrun==0){ //not running but there are new arrive process
			boolrun=1;
			boolsche=1;

			for(int b=0;b<runQ.size();b=b+2){
				if(b==0){
					temppid=stoi(runQ[b]);
					minid=temppid;
					min=processif[minid].S.back();
					mindex=0;
				}
				else{
					temppid=stoi(runQ[b]);
					if(min>processif[temppid].S.back()){
						min=processif[runpid].S.back();
						minid=temppid;
						mindex=b;
					}
				}

			}
			
			
//find out the smaller S

			runpid=stoi(runQ[mindex]);
			runname=runQ[mindex+1];
			runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
			processif[runpid].cpubust++;
//selecting here-----------------------------------------------------------------------------------

			
			processif[runpid].readline++;
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
			}
			else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				
				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				boolsche=0;

			}
			intorun=0;
		}

		else if(intorun==0 && boolrun==0){ //not running and no arrive process

			if(runQ.empty()){
				boolsche=0;
				noop.push_back(time00);
				printscheduler(runQ,sleepL,IOW,processif[0],time00,boolrun,boolsche);
			}
			else{
				boolrun=1;
				boolsche=1;

				for(int b=0;b<runQ.size();b=b+2){

					if(b==0){
						temppid=stoi(runQ[b]);
						minid=temppid;
						min=processif[minid].S.back();
						mindex=0;
					}
					else{
						temppid=stoi(runQ[b]);
						if(min>processif[temppid].S.back()){
							min=processif[temppid].S.back();
							minid=runpid;
							mindex=b;
						}
					}
				}
		
			
	//find out the smaller S

				runpid=stoi(runQ[mindex]);
				runname=runQ[mindex+1];
				runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
				processif[runpid].cpubust++;
//select in runq ------------------------------------------------------------------------------------------------------

				processif[runpid].readline++;
				codenum=processif[runpid].alldocu[0];
				codetime=processif[runpid].alldocu[1];
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
				processif[runpid].op=stoi(codenum);
				processif[runpid].arg=stoi(codetime);
				if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
					sleepL.push_back(to_string(processif[runpid].pid));
					sleepL.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].sleeptime=stoi(codetime);
					boolrun=0;
				}
				else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
					
					IOW.push_back(to_string(processif[runpid].pid));
					IOW.push_back(processif[runpid].name);
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					processif[runpid].iowait=1;
					boolrun=0;	
				}
				else{
					printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
					boolsche=0;
				}
				if(processif[runpid].readline==processif[runpid].linenum){
					processif[runpid].end=1;
					endtime[runpid]=time00;
					boolrun=0;
				}
				
			}
		}
		else if(boolrun==1){ //running now

			boolsche=0;
			for(int b=0;b<runQ.size();b=b+2){

				if(b==0){
					temppid=stoi(runQ[b]);
					minid=temppid;
					min=processif[temppid].S.back();
					mindex=0;
				}
				else{
					temppid=stoi(runQ[b]);
					if(min>processif[temppid].S.back()){
						min=processif[temppid].S.back();
						minid=temppid;
						mindex=b;
					}
				}
			}
			processif[runpid].cpubust++;
			if((processif[runpid].S.back()-processif[runpid].cpubust)>min){ 			//change the running 

				processif[runpid].cpubust--;				
				temppid=stoi(runQ[mindex]);
				tempname=runQ[mindex+1];
				runQ.erase(runQ.begin()+mindex,runQ.begin()+(mindex+2));
				runQ.push_back(to_string(runpid));
				runQ.push_back(runname);

				runpid=temppid;
				runname=tempname;
				boolsche=1;
				processif[runpid].cpubust++;
			}
	//find out the smaller S

			
			
			processif[runpid].readline++;
			codenum=processif[runpid].alldocu[0];
			codetime=processif[runpid].alldocu[1];
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);
			processif[runpid].alldocu.erase(processif[runpid].alldocu.begin(),processif[runpid].alldocu.begin()+2);
			processif[runpid].op=stoi(codenum);
			processif[runpid].arg=stoi(codetime);

			if(codenum=="4"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------
				sleepL.push_back(to_string(processif[runpid].pid));
				sleepL.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].sleeptime=stoi(codetime);
				boolrun=0;
				boolsche=1;
			}
			else if(codenum=="5"){
//---------------------------------------------------------------update T,S----------------------------------
					processif[runpid].T.push_back(processif[runpid].cpubust);
					min=0;
					if(processif[runpid].T.size()==1){
						SSS=processif[runpid].cpubust;
					}
					else{
						SSS=(0.6*(processif[runpid].cpubust/processif[runpid].T.size()))+(0.4*((processif[runpid].S.back()/processif[runpid].T.size()))*(processif[runpid].T.size()-1));
					}
					processif[runpid].S.push_back(SSS);
					processif[runpid].cpubust=0;
//---------------------------------------------------------------update T,S----------------------------------

				IOW.push_back(to_string(processif[runpid].pid));
				IOW.push_back(processif[runpid].name);
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);
				processif[runpid].iowait=1;
				boolrun=0;
				boolsche=1;
			}
			else{
				printscheduler(runQ,sleepL,IOW,processif[runpid],time00,boolrun,boolsche);

			}
			boolsche=0;
			if(processif[runpid].readline==processif[runpid].linenum){
				processif[runpid].end=1;
				endtime[runpid]=time00;
				boolrun=0;
			}

			if(intorun==1){
				intorun=0;
			}
		}

		allorder.push_back(to_string(runpid));
		allorder.push_back(codenum);
		allorder.push_back(codetime);
		//putting for memory

	
		int end=0;
		for(int o=0;o<pidnum;o++){
			if(processif[o].end !=1){
				end=0;
				break;
			}
			end=1;	
		}
		if(end==1){
			break;
		}
	}
	//----------------------------------ending-------------------------------------

//--------------------memory start----------------------------------------	
	if(page=="fifo"){
		FIFO(allorder);
	}
	else if(page=="lru"){
		LRU(allorder);
	}
	else if(page=="lru-sampled"){
		LRU_SAMPLED(allorder);
	}
	else if(page=="lfu"){
		LFU(allorder);
	}
	else if(page=="mfu"){
		MFU(allorder);
	}
	else if(page=="optimal"){
		OPTIMAL(allorder);
	}
//---------------------------end all---------------------------------------			
}



//-----------------------------------------------------------------main----------------------------------------------------------------------
int main(int argc, char ** argv){
	string in [argc];
	string input [argc-1][2];	
	char *str_buff= new char[100];
	int str_cnt=0;
	string str_arr[100];



	for(int i=1;i<argc;i++){
		
		in[i]=argv[i];
		strcpy(str_buff,in[i].c_str());
		char *tok = strtok(str_buff,"=");
		while(tok != nullptr){		
			str_arr[str_cnt++]=string(tok);
			tok = strtok(nullptr,"=");
		}
		input[i-1][0]=str_arr[0];
		input[i-1][1]=str_arr[1];
		str_cnt=0;
		
	}
	// split the input with "="

	int boolsched=0,boolpage=0,booldir=0; //bool the input is exit
	string sched,page,dir;

	for(int a=0;a<argc-1;a++){
		if(input[a][0]=="-sched"){
			boolsched=1;
			sched=input[a][1];
		}
		else if(input[a][0]=="-page"){
			boolpage=1;
			page=input[a][1];
		}
		else if(input[a][0]=="-dir"){
			booldir=1;
			dir=input[a][1]+"/";
		}
	}
	//put the input value 
	if(booldir==0){
		dir=""; //initial dir
	}
	if(boolpage==0){
		page="fifo";
	}

	
	if(boolsched==0){
		sched="fcfs";
	}
	if(sched=="fcfs"){
		FCFS(dir,page);
	}
	else if(sched=="rr"){
		RR(dir,page);
	}
	else if(sched=="sjf-simple"){
		SJF_SIMPLE(dir,page);
	}
	else if(sched=="sjf-exponential"){
		SJF_EXP(dir,page);
	}

	
	

return 0;
}
