#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

using namespace std;

int checkpid[128];  	// inode pid
int leftblock=973;		//all left block size

struct INODE{
	int id;					// inode ID(0~127)
	char name[64];			// inode name (file name)
	int size;				// file size
	

	int direct_block;	
	int single_indirect;
	int double_indirect;

	int totalblock;
};

struct DENTRY{
	char name[64];		//dentry name(directory name)
	char pathname[100];

	DENTRY* parent;			//parent dentry
	DENTRY* d_dentry;		//a list of children dentries		
	INODE* d_inode;			//a list of inodes
	
	int dentrynum;			//size of have dentry
	int inodenum;			//size of have inode
};



struct SUPER_BLOCK{
	struct DENTRY s_root;		//parent dentry
};


void deletedir(DENTRY delcurrent){
	

	for(int m=0;m<delcurrent.inodenum;m++){
		leftblock = leftblock + delcurrent.d_inode[m].totalblock;
		checkpid[delcurrent.d_inode[m].id] = 0;
	}
							
	for(int n=0;n<delcurrent.dentrynum;n++){
		deletedir(delcurrent.d_dentry[n]);			
	}

} 					

int main(){

	char sinput[100];				//reading the string
	char sinput1[100];
	SUPER_BLOCK firstp;			//frist root firstparent = firstp

	DENTRY starting;			// firstp = starting dentry
	

//initalize the all content
	string temp="/";
	strcpy(starting.pathname, temp.c_str());
	strcpy(starting.name, temp.c_str());
	starting.parent = new DENTRY[1];
	starting.d_dentry = new DENTRY[64];
	starting.d_inode = new INODE[128];
	starting.dentrynum=0;
	starting.inodenum=0;
	starting.parent[0] = starting;


	DENTRY current;
	current = starting;			// the directory where we are now

	for(int b=0;b<128;b++){
		checkpid[b]=0;
	} 							//checking the pid is use or not


	while(1){
		cout<<"2015147533:"<<current.pathname<<"$ ";	//print order
		cin.getline(sinput,100);					//read line
		strcpy(sinput1, sinput);
		char *ptr = strtok(sinput," ");				//split with " "
//==========================================================================================
		if(strcmp(sinput,"exit")==0){
			break;
		}
//------------------------------------- org = exit--------------------------
		else if(strcmp(sinput,"ls")==0){
			for(int i=0;i<current.dentrynum;i++){
				cout<<current.d_dentry[i].name<<" ";
			}						//print dentry name
			for(int i=0;i<current.inodenum;i++){
				cout<<current.d_inode[i].name<<" ";
			}						//print inode name
			cout<<endl;
						
		}
//------------------------------------- org = ls--------------------------
		else if(strcmp(sinput,"cd")==0){
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;				//cout<<"CD NULL ERROR"<<endl;
			}
			else{

				if(strcmp(current.parent[0].pathname,current.pathname)==0){
					current.parent[0]=current;
					starting = current;
				}							// when in root
				string tem1 =ptr;
				if(strcmp(tem1.c_str(),"..")==0){
					if(strcmp(current.parent[0].pathname,current.pathname)==0){
						cout<<"error"<<endl;			//cout<<"ERROR already root"<<endl;
					}
					else{
						for(int v=0; v<current.parent[0].dentrynum;v++){
							if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
								current.parent[0].d_dentry[v]=current;
								break;
							}
						}
						current = current.parent[0];
					}						//paste current and move to parent
				}
				else{
					char * cdtok = new char[100];
					strcpy(cdtok,tem1.c_str());
//----------------------------------------------------------------------------------------------find from root(/ arg) start------------------------------------------------------
					if(cdtok[0] =='/'){
						DENTRY coco;
						coco = current;
						while(1){
							if(strcmp(coco.parent[0].pathname,coco.pathname)==0){
								coco.parent[0]=coco;
								starting=coco;
								break;
							}
							for(int v=0; v<coco.parent[0].dentrynum;v++){
								if(strcmp(coco.parent[0].d_dentry[v].name,coco.name)==0){
									coco.parent[0].d_dentry[v]=coco;
									break;
								}
							}
							coco = coco.parent[0];
						}					//update to the root path
						DENTRY tempcurrent;
						tempcurrent = starting;
						char *ptr = strtok(cdtok,"/");
						string yeun;
						if(ptr ==NULL){
							if(strcmp(current.parent[0].pathname,current.pathname)==0){
									current = tempcurrent;
								}
								else{
									for(int v=0; v<current.parent[0].dentrynum;v++){
										if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
											current.parent[0].d_dentry[v]=current;
											current = tempcurrent;	
											break;
										}
									}
								}	
						}					//move to root
						else{
							yeun =ptr;
							int boolfind =0;						//bool if exist or not
							for(int v=0;v<tempcurrent.dentrynum;v++){							
								if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){
									tempcurrent=tempcurrent.d_dentry[v];
									boolfind=1;
									break;
								}
							}

							while(1){
								if(boolfind==0){
									cout<<"error"<<endl;			//cout<<"ERROR NOT cd exist(/)"<<endl;
									break;
								}
								
								ptr =strtok(NULL,"/");
								if(ptr==NULL){
									break;
								}
								else{
									yeun =ptr;
									boolfind =0;						//bool if exist or not
									for(int v=0;v<tempcurrent.dentrynum;v++){							
										if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){
											tempcurrent=tempcurrent.d_dentry[v];
											boolfind=1;
											break;
										}
									}
								}
							}					//finding the following path
							if(boolfind==1){
								if(strcmp(current.parent[0].pathname,current.pathname)==0){
									current = tempcurrent;
								}
								else{
									for(int v=0; v<current.parent[0].dentrynum;v++){
										if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
											current.parent[0].d_dentry[v]=current;
											current = tempcurrent;	
											break;
										}
									}
								}
							}				//if find move the path
						}	
					}										
//----------------------------------------------------------------------------------------------find from root(/ arg) end------------------------------------------------------

//----------------------------------------------------------------------------------------------find from root(./ arg) start------------------------------------------------------
					else if(cdtok[0] =='.' && cdtok[1] == '/'){
						int boolfind =0;
						DENTRY tempcurrent;
						tempcurrent = current;

						char *ptr = strtok(cdtok,"/");	
						string yeun;							
						while(1){
							ptr =strtok(NULL,"/");
							if(ptr==NULL){
								break;
							}
							else{
								yeun =ptr;
								boolfind =0;
								for(int v=0;v<tempcurrent.dentrynum;v++){							
									if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){	
										tempcurrent=tempcurrent.d_dentry[v];	
										boolfind=1;
										break;
									}
								}
								if(boolfind==0){
									cout<<"error"<<endl;			//cout<<"ERROR NOT cd exist(./)"<<endl;
									break;
								}
							}
						}						//check the following path
						if(boolfind==1){
							if(strcmp(current.parent[0].pathname,current.pathname)==0){							
								current = tempcurrent;
							}
							else{
								for(int v=0; v<current.parent[0].dentrynum;v++){
									if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
										current.parent[0].d_dentry[v]=current;
										current = tempcurrent;	
										break;
									}
								}
							}
						}					//if find move to that path
					}											//find from current
//----------------------------------------------------------------------------------------------find from root(./ arg) end------------------------------------------------------
//----------------------------------------------------------------------------------------------find from now( ../) start------------------------------------------------------
					else if(cdtok[0] =='.' && cdtok[1] == '.'){
						int boolfind =0;
						DENTRY tempcurrent;
						tempcurrent = current;
						char * ptr= strtok(cdtok,"/");
						tempcurrent = tempcurrent.parent[0];
						boolfind = 1;					
						while(1){	
							ptr =strtok(NULL,"/");	
							string yeun;
							string up="..";
							if(ptr==NULL){
								break;
							}
							else{
								yeun =ptr;
								if(yeun==up){
									tempcurrent = tempcurrent.parent[0];
									boolfind =1;
								
								}
								else{
									boolfind=0;
									for(int v=0;v<tempcurrent.dentrynum;v++){							
										if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){	
											tempcurrent=tempcurrent.d_dentry[v];	
											boolfind=1;
											break;
										}
									}
									if(boolfind==0){
										cout<<"error"<<endl;			//cout<<"ERROR NOT cd exist(./)"<<endl;
										break;
									}


								}

							}
						}						//check the following path
						if(boolfind==1){
							if(strcmp(current.parent[0].pathname,current.pathname)==0){							
								current = tempcurrent;
							}
							else{
								for(int v=0; v<current.parent[0].dentrynum;v++){
									if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
										while(1){
											if(strcmp(current.parent[0].pathname,current.pathname)==0){							
												break;
											}
											current.parent[0].d_dentry[v]=current;
											current = current.parent[0];
										}
										current = tempcurrent;		
										break;
									}
								}
							}
						}										




					}
//----------------------------------------------------------------------------------------------find from now( ../) end------------------------------------------------------
//----------------------------------------------------------------------------------------------find from root( dir) start------------------------------------------------------
					else{
						int boolfind =0;
						DENTRY tempcurrent;
						tempcurrent = current;

						char *ptr = strtok(cdtok,"/");	
						string yeun;	
						yeun =ptr;
						boolfind =0;
						for(int v=0;v<tempcurrent.dentrynum;v++){							
							if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){	
								tempcurrent=tempcurrent.d_dentry[v];	
								boolfind=1;
								break;
							}
						}						
						while(1){
							ptr =strtok(NULL,"/");
							if(ptr==NULL){
								break;
							}
							else{
								yeun =ptr;
								boolfind =0;
								for(int v=0;v<tempcurrent.dentrynum;v++){							
									if(strcmp(tempcurrent.d_dentry[v].name,yeun.c_str())==0){	
										tempcurrent=tempcurrent.d_dentry[v];	
										boolfind=1;
										break;
									}
								}
								if(boolfind==0){
									cout<<"error"<<endl;			//cout<<"ERROR NOT cd exist(./)"<<endl;
									break;
								}
							}
						}						//check the following path
						if(boolfind==1){
							if(strcmp(current.parent[0].pathname,current.pathname)==0){							
								current = tempcurrent;
							}
							else{
								for(int v=0; v<current.parent[0].dentrynum;v++){
									if(strcmp(current.parent[0].d_dentry[v].name,current.name)==0){
										current.parent[0].d_dentry[v]=current;
										current = tempcurrent;	
										break;
									}
								}
							}
						}




					}											//find from now
//----------------------------------------------------------------------------------------------find from root( dir ) end------------------------------------------------------
				}

			}				
			
		}	
//------------------------------------- org = cd--------------------------
		else if(strcmp(sinput,"mkdir")==0){
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;				//cout<<"mkdir NULL ERROR"<<endl;
			}
			else{
				int already = 0;
				while(1){
					string check = ptr;
					for(int z=0;z<current.dentrynum;z++){
						if(strcmp(current.d_dentry[z].name,check.c_str())==0){
							already = 1;
						}
					}
					ptr=strtok(NULL," ");
					if(ptr == NULL){
						break;
					}						//check if it is exist or not
				}
				if(already ==1){
					cout<<"error"<<endl;				//cout<<"ERROR already have"<<endl;
				}
				else{
					ptr = strtok(sinput1," ");
					ptr=strtok(NULL," ");
					while(1){
						DENTRY newdentry;
						newdentry.dentrynum=0;
						newdentry.inodenum=0;
						newdentry.parent = new DENTRY[1];
						newdentry.d_dentry = new DENTRY[64];
						newdentry.d_inode = new INODE[128];
						newdentry.parent[0]=current;						//make new dentry and put the new info
						string tem2(current.pathname);
						string tem = ptr;
						strcpy(newdentry.name,tem.c_str());					// update the name
						if(tem2=="/"){
							tem = tem2 + tem;							
							strcpy(newdentry.pathname,tem.c_str());				//update the new path with adding /
						}
						else{
							tem = tem2 + "/" +tem;							
							strcpy(newdentry.pathname,tem.c_str());				//update the new path with adding /
						}
						current.d_dentry[current.dentrynum] = newdentry;
						current.dentrynum++;
						for(int v=0;v<current.dentrynum;v++){
							current.d_dentry[v].parent[0]=current;
						}
						ptr=strtok(NULL," ");
						if(ptr ==NULL){
							break;
						}	
					}
				}
			}
		}
//------------------------------------- org = mkdir--------------------------	
		else if(strcmp(sinput,"rmdir")==0){
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;				//cout<<"rmdif NULL ERROR"<<endl;
			}
			else{
				int boolfind = 0;
				while(1){
					boolfind=0;
					string check = ptr;
					for(int z=0;z<current.dentrynum;z++){
						if(strcmp(current.d_dentry[z].name,check.c_str())==0){
							boolfind = 1;
						}
					}						//check if it is exist or not
					if(boolfind == 0){
						cout<<"error"<<endl;			//cout<<"ERROR NOT exist dir"<<endl;
						break;
					}
					ptr=strtok(NULL," ");
					if(ptr == NULL){
						break;
					}
				}
				if(boolfind ==1){
					ptr = strtok(sinput1," ");
					ptr=strtok(NULL," ");
					while(1){
						string tem1 =ptr;
						for(int v=0;v<current.dentrynum;v++){
							if(strcmp(current.d_dentry[v].name,tem1.c_str())==0){
								DENTRY delcurrent;
								delcurrent = current.d_dentry[v];
								deletedir(delcurrent);												//when do rmdir, check the remain blocks with in rm dir
			
								for(int z=v;z<current.dentrynum-1;z++){
									current.d_dentry[z]=current.d_dentry[z+1];
								}
								break;
							}
						}
						current.dentrynum--;
						for(int v=0;v<current.dentrynum;v++){
							current.d_dentry[v].parent[0]=current;
						}
						ptr=strtok(NULL," ");
						if(ptr ==NULL){
							break;
						}
					}
					cout<<"Now you have ..."<<endl;
					cout<<leftblock<<" / 973 (blocks)"<<endl;
				}
			}
		}
//------------------------------------- org = rmdir--------------------------
		else if(strcmp(sinput,"mkfile")==0){
			INODE newinode;			//create new inode
			string tem;

			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;			//cout<<"mkfile NULL ERROR1"<<endl;
			}
			else{
				tem = ptr;
			}
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;			//cout<<"mkfile NULL ERROR2"<<endl;
			}
			else{
				if(leftblock <1 ){
					cout<<"error"<<endl;			//cout<<"ERROR NO block left"<<endl;
				}
				else{
					int find =0;
					for(int g=0;g<current.inodenum;g++){
						if(strcmp(current.d_inode[g].name,tem.c_str())==0){
							find =1;
							break;
						}
					}
					if(find ==1){
						cout<<"error"<<endl;		//cout<<"ERROR already exist file"<<endl;
					}
					else{
						strcpy(newinode.name,tem.c_str());					// update the name
						string tem1 = ptr;
						int noblock = 0;
						int total =0;
						if(atoi(tem1.c_str()) ==0){
							total = -1;
						}
						else{
							total = stoi(tem1);
						}
						if(total < 1){
							cout<<"error"<<endl;
						}
						else{
							int tblock = total/1024;
							int tblockleft = total%1024;
							if(tblockleft !=0){
								tblock=tblock+1;
							}
							if(tblock<13){
								if(leftblock<tblock){
									noblock = 1;
								}
							}
							else if(tblock <269){
								if(leftblock<tblock+1){
									noblock = 1;
								}
							}
							else{
								int V = ((tblock-268)/256)+1;
								int F = (tblock-268)%256;
								if(F==0){
									V=V-1;
								}
								if(leftblock<(270+V+((V-1)*256)+F)){
									noblock = 1;
								}

							} 
							if(noblock ==1){
								cout<<"error"<<endl;			//cout<<"Not enough block"<<endl;
							}
							else{
								newinode.size = total;								//update the size
								if(tblock<13){
									newinode.direct_block=tblock;
									newinode.single_indirect=0;
									newinode.double_indirect=0;
									newinode.totalblock =tblock;
									leftblock=leftblock - newinode.totalblock;
								}
								else if(tblock<269){
									newinode.direct_block=12;
									newinode.single_indirect=(tblock-12)+1;
									newinode.double_indirect=0;
									newinode.totalblock = (tblock+1);
									leftblock =leftblock - newinode.totalblock;
								}
								else{
									newinode.direct_block=12;
									newinode.single_indirect=256+1;
									newinode.double_indirect=(tblock-268);
									int S = (newinode.double_indirect/256)+1;
									int R = newinode.double_indirect%256;
									if(R==0){
										S=S-1;
									}
									newinode.double_indirect=(1+S+((S-1)*256)+R);
									newinode.totalblock = (270+S+((S-1)*256)+R);
									leftblock =leftblock - newinode.totalblock;
								}

																					//update the block;
								for(int c=0;c<128;c++){
									if(checkpid[c]==0){
										checkpid[c]=1;
										newinode.id = c;
										break;
									}
								}										//check unuse pidnum and update the pid;
								current.d_inode[current.inodenum] = newinode;
								current.inodenum++;

								cout<<"Now you have ..."<<endl;
								cout<<leftblock<<" / 973 (blocks)"<<endl;
							}
						}
					}
				}
			}

		}	
//------------------------------------- org = mkfile--------------------------
		else if(strcmp(sinput,"rmfile")==0){
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;	//cout<<"rmfile NULL ERROR"<<endl;
			}
			else{
				int boolfind = 0;
				while(1){
					boolfind=0;
					string check = ptr;
					for(int z=0;z<current.inodenum;z++){
						if(strcmp(current.d_inode[z].name,check.c_str())==0){
							boolfind = 1;
						}
					}							//check if it is exist or not
					if(boolfind == 0){
						cout<<"error"<<endl;	//cout<<"ERROR NOT exist file"<<endl;
						break;
					}
					ptr=strtok(NULL," ");
					if(ptr == NULL){
						break;
					}
				}
				if(boolfind ==1){
					ptr = strtok(sinput1," ");
					ptr=strtok(NULL," ");
					while(1){
						string tem1 =ptr;
						for(int v=0;v<current.inodenum;v++){
							if(strcmp(current.d_inode[v].name,tem1.c_str())==0){
								leftblock = leftblock + current.d_inode[v].totalblock;				//adding the delete block
								checkpid[current.d_inode[v].id]=0;
								for(int z=v;z<current.inodenum-1;z++){
									current.d_inode[z]=current.d_inode[z+1];
								}
								break;
							}
						}
						current.inodenum--;
						ptr=strtok(NULL," ");
						if(ptr ==NULL){
							break;
						}
					}
					cout<<"Now you have ..."<<endl;
					cout<<leftblock<<" / 973 (blocks)"<<endl;
				}
			}
		}				
//------------------------------------- org = rmfile--------------------------
		else if(strcmp(sinput,"inode")==0){
			ptr=strtok(NULL," ");
			if(ptr == NULL){
				cout<<"error"<<endl;	//cout<<"inode NULL ERROR1"<<endl;
			}
			else{
				string tem1 =ptr;
				int boolfind = 0;
				for(int v=0;v<current.inodenum;v++){
					if(strcmp(current.d_inode[v].name,tem1.c_str())==0){
						boolfind =1;
						cout<<"ID: "<<current.d_inode[v].id<<endl;
						cout<<"Name: "<<current.d_inode[v].name<<endl;
						cout<<"Size: "<<current.d_inode[v].size<<" (bytes)"<<endl;
						cout<<"Direct blocks: "<<current.d_inode[v].direct_block<<endl;
						cout<<"Single indirect blocks: "<<current.d_inode[v].single_indirect<<endl;
						cout<<"Double indirect blocks: "<<current.d_inode[v].double_indirect<<endl;
						break;
					}
				}
				if(boolfind == 0){
					cout<<"error"<<endl; //not exist
				}
			}
		}
//------------------------------------- org = inode--------------------------
		else{
			//cout<<"Wrong Input"<<endl;
			
		}
//------------------------------------- org = error--------------------------
	}
	
return 0;
}  
